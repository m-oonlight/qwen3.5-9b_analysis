GGUF weights are not included. Copy the five verified GGUF files from the original models folder, or run scripts/download_quantizations.py. Checksums and pinned revision are in environment/.
