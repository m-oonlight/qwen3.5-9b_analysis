"""Run authored correct solutions through actual RUNNER namespace; no Docker enforcement claim."""
import ast,contextlib,io,json,sys
from pathlib import Path
from unittest.mock import patch
from study_code_harness_v2 import RUNNER,policy
P=Path(__file__).resolve().parents[1];keys=json.loads((P/'datasets/study_v2/private/answer_keys.json').read_text())
variants=[('COD-03','def solve(s):\n counts={}\n for c in s:counts[ord(c)]=counts.get(ord(c),0)+1\n for i,c in enumerate(s):\n  if counts[ord(c)]==1:return i\n return -1'),('COD-02',"PAIRS={')':'(',']':'[','}':'{'}\ndef solve(s: str) -> bool:\n stack=[]\n for c in s:\n  if c in '([{':stack.append(c)\n  elif c in PAIRS:\n   if not stack or stack.pop()!=PAIRS[c]:return False\n return not stack"),('COD-08','def solve(grid):\n if not grid or not grid[0]:return 0\n memo={}\n def count(i,j):\n  if i<0 or j<0 or grid[i][j]:return 0\n  if i==0 and j==0:return 1\n  if (i,j) not in memo:memo[(i,j)]=count(i-1,j)+count(i,j-1)\n  return memo[(i,j)]\n return count(len(grid)-1,len(grid[0])-1)')]
sources=[(id,k['reference_code']) for id,k in keys.items() if id.startswith('COD')]+variants
for id,code in sources:
 assert policy(code)==(None,None),(id,policy(code))
 payload=json.dumps({'code':code,'task_id':id,'cases':keys[id]['expected']['cases']});output=io.StringIO()
 with patch('builtins.open',lambda *args,**kwargs:io.StringIO(payload)),contextlib.redirect_stdout(output):exec(RUNNER,{})
 result=json.loads(output.getvalue());assert result['correct'],(id,result)
print('PASS: 10 references + ord + literal constant/annotations + recursion under actual restricted-builtins RUNNER.')
assert policy('N=pow(2,3)\ndef solve(x):return x')[0]=='top_level_policy_failure'
assert policy('def solve(x):return open("x")')[0]=='unsafe_code_policy_failure'
