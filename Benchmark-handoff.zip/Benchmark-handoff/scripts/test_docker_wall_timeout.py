import json,os,subprocess
from pathlib import Path
import study_code_harness_v2 as h
p=Path(__file__).resolve().parents[1];image=(p/'environment/docker_image_digest.txt').read_text().strip()
# Trusted probe runner sleeps without consuming CPU, exercising the host timeout branch.
h.RUNNER='import time;time.sleep(60)'
r=h.score_code('def solve(x):return x','TIMEOUT',[],image)
assert r['status']=='execution_timeout',r
left=subprocess.check_output(['docker','ps','-a','--filter','name=study-v2-','--format','{{.Names}}']).decode().strip();assert not left,left
out=p/'environment/docker_wall_timeout.json';out.write_text(json.dumps({'result':r,'leftovers':left,'passed':True},indent=2)+'\n');s=p.stat();os.chown(out,s.st_uid,s.st_gid);print('20-second wall timeout and cleanup PASSED',flush=True)
