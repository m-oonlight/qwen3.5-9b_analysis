import json,hashlib,copy
from pathlib import Path
from study_score_v2 import score_final
from study_code_harness_v2 import policy
P=Path(__file__).resolve().parents[1];D=P/'datasets/study_v2';keys=json.loads((D/'private/answer_keys.json').read_text());tasks=json.loads((D/'public/tasks.json').read_text());m=json.loads((D/'manifest.json').read_text())
for name,digest in m['hashes'].items():assert hashlib.sha256((D/name).read_bytes()).hexdigest()==digest,name
count=0
for t in tasks:
 key=keys[t['id']]
 if t['category']!='coding':
  x='work\nFINAL_JSON: '+json.dumps(key['expected']);assert score_final(x,key,t['category'],'stop')['correct'],t['id'];continue
 source=key['reference_code'];assert policy(source)==(None,None)
 ns={};exec(source,ns) # Authored references ONLY, never model output.
 for c in key['expected']['cases']:
  x=copy.deepcopy(c['input']);before=copy.deepcopy(x);got=ns['solve'](x);assert got==c['expected'];assert x==before
  if t['id']=='COD-05':assert got is not x['values']
  count+=1
k={'expected':{'n':44}}
checks=[('FINAL_JSON: {"n":44}','stop','correct'),('FINAL_JSON: {"n":44.0}','stop','schema_failure'),('FINAL_JSON: {"n":"44"}','stop','schema_failure'),('FINAL_JSON: {"value":44}','stop','schema_failure'),('FINAL_JSON: ```json\n{"n":44}\n```','stop','format_failure'),('**FINAL_JSON:** {"n":44}','stop','format_failure'),('FINAL_JSON: {"n":0,"n":44}','stop','duplicate_keys'),('<think>FINAL_JSON: {"n":44}</think>','stop','no_final_answer'),('FINAL_JSON: {"n":44}','length','truncated'),('FINAL_JSON: {"n":44}','content_filter','incomplete_response'),('FINAL_JSON: {"n":45}','stop','wrong_answer')]
for text,finish,expected in checks:assert score_final(text,k,'reasoning',finish)['status']==expected,(text,score_final(text,k,'reasoning',finish))
assert score_final('FINAL_JSON: {"n":44}',{'n':44},'reasoning','stop')['correct']
assert score_final('FINAL_CODE:\n```python\ndef solve(x):\n return x\n```',{},'coding','stop')['code']=='def solve(x):\n return x'
assert policy('import os\ndef solve(x): return x')[0]=='import_policy_failure'
assert policy('print(1)\ndef solve(x): return x')[0]=='top_level_policy_failure'
assert policy('def solve(x): return eval(x)')[0]=='unsafe_code_policy_failure'
mutants={
 'COD-01':[keys['COD-01']['reference_code'].replace('max(out[-1][1],b)','b')],
 'COD-02':[keys['COD-02']['reference_code'].replace('pairs={', 'pairs={">":"<",').replace('"([{":','"([{<":')],
 'COD-04':['def solve(xs):\n return max([xs.count(x) for x in xs] or [0])','def solve(xs):\n return sum(i==0 or xs[i]!=xs[i-1] for i in range(len(xs)))',keys['COD-04']['reference_code'].replace('return best','return max([len(list(g)) for _,g in __import__("itertools").groupby(xs[:-1])] or [0])')],
 'COD-05':[keys['COD-05']['reference_code'].replace('k%=len(xs)','k=k'),'def solve(d):\n return d["values"]'],
 'COD-07':[keys['COD-07']['reference_code'].replace('out[-1][0]==c','out[-1][0].lower()==c.lower()')],
 'COD-08':[keys['COD-08']['reference_code'].replace('if blocked:dp[j]=0','if blocked and not (row is g[0] and j==0):dp[j]=0')],
 'COD-09':['def solve(d):\n adj=[[] for _ in range(d["n"])]\n for a,b in d["edges"]:adj[a].append(b);adj[b].append(a)\n def dfs(x,seen):\n  if x==d["goal"]:return 0\n  for y in adj[x]:\n   if y not in seen:\n    z=dfs(y,seen|{y})\n    if z>=0:return z+1\n  return -1\n return dfs(d["start"],{d["start"]})'],
 'COD-10':['def solve(d):\n n=d["n"];adj=[[] for _ in range(n)];ind=[0]*n\n for a,b in d["edges"]:adj[a].append(b);ind[b]+=1\n q=[i for i in range(n) if ind[i]==0];out=[]\n for x in q:\n  out.append(x)\n  for y in adj[x]:\n   ind[y]-=1\n   if ind[y]==0:q.append(y)\n return out if len(out)==n else None']}
rejected=[]
for id,sources in mutants.items():
 for j,source in enumerate(sources):
  ns={};exec(source,ns);killed=False
  for c in keys[id]['expected']['cases']:
   x=copy.deepcopy(c['input']);before=copy.deepcopy(x)
   try:
    result=ns['solve'](x);bad=result!=c['expected'] or x!=before or (id=='COD-05' and result is x['values'])
   except Exception:bad=True
   if bad:killed=True;break
  assert killed,(id,j,'mutant survived');rejected.append(f'{id}:{j}')
print(json.dumps({'validated_tasks':60,'coding_cases':count,'scorer_regressions':len(checks)+2,'rejected_known_wrong_programs':len(rejected),'docker_execution_tested':False},indent=2))
