#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
model="$(realpath "$1")"
shift
read -r context output batch ubatch cache_k cache_v parallel reasoning_budget < <(python3 - <<'PYCONFIG'
import json
c=json.load(open('config/experiment.json'))
print(c['context_tokens'],c['max_output_tokens'],c['batch_tokens'],c['ubatch_tokens'],c['kv_cache_type_k'],c['kv_cache_type_v'],c['parallel_sequences'],c.get('reasoning_budget_tokens',-1))
PYCONFIG
)
exec llama.cpp/build/bin/llama-server --jinja --reasoning on --reasoning-budget "$reasoning_budget" -m "$model" --gpu-layers all --fit off --override-tensor token_embd.weight=CUDA0 -c "$context" -n "$output" -b "$batch" -ub "$ubatch" -ctk "$cache_k" -ctv "$cache_v" --threads 16 --threads-batch 16 --flash-attn auto --host 127.0.0.1 --port 8080 --parallel "$parallel" "$@"
