import os
from pathlib import Path
root=Path(__file__).resolve().parents[1]
os.environ['HF_HOME']=str(root/'models/.hf-cache')
os.environ['HF_HUB_DISABLE_XET']='1'
import hashlib,json,datetime
from huggingface_hub import HfApi,hf_hub_download
repo='bartowski/Qwen_Qwen3.5-9B-GGUF'
revision=(root/'environment/gguf_revision.txt').read_text().strip()
config=json.loads((root/'config/experiment.json').read_text())
info=HfApi().model_info(repo,revision=revision,files_metadata=True)
files={f.rfilename:f for f in info.siblings}
items=[]
for quant in config['quantizations']:
 name=f'Qwen_Qwen3.5-9B-{quant}.gguf';f=files[name]
 if not f.lfs or not f.lfs.sha256:raise SystemExit('Publisher SHA256 absent: '+name)
 items.append({'quantization':quant,'filename':name,'size':f.size,'expected_sha256':f.lfs.sha256,'status':'pending'})
manifest={'repository':repo,'revision':revision,'files':items}
path=root/'environment/quantization_downloads.json'
def save():path.write_text(json.dumps(manifest,indent=2)+'\n')
save()
for item in items:
 item['status']='downloading';save();print('Downloading/checking',item['filename'],flush=True)
 try:
  target=Path(hf_hub_download(repo_id=repo,revision=revision,filename=item['filename'],local_dir=root/'models'))
  if target.stat().st_size!=item['size']:raise ValueError('Size mismatch')
  item['status']='verifying';save();h=hashlib.sha256()
  with target.open('rb') as stream:
   for b in iter(lambda:stream.read(8*1024*1024),b''):h.update(b)
  item['actual_sha256']=h.hexdigest()
  if item['actual_sha256']!=item['expected_sha256']:raise ValueError('SHA256 mismatch')
  item['status']='verified';item['verified_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
  print('VERIFIED',item['filename'],flush=True)
 except Exception as e:
  item['status']='failed';item['error']=str(e);save();raise
(root/'environment/quantized_models.sha256').write_text(''.join(i['actual_sha256']+'  models/'+i['filename']+'\n' for i in items))
print('All five model files verified.',flush=True)
