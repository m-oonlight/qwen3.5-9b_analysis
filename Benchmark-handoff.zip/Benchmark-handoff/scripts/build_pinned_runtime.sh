#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
revision="$(cat environment/llama_cpp_commit.txt)"
if [ ! -d llama.cpp ]; then git clone https://github.com/ggml-org/llama.cpp.git; fi
git -C llama.cpp checkout --detach "$revision"
cmake -S llama.cpp -B llama.cpp/build -G Ninja -DCMAKE_BUILD_TYPE=Release -DGGML_CUDA=ON -DCMAKE_C_COMPILER=/usr/bin/gcc-12 -DCMAKE_CXX_COMPILER=/usr/bin/g++-12 -DCMAKE_CUDA_HOST_COMPILER=/usr/bin/g++-12
cmake --build llama.cpp/build --config Release -j 16
