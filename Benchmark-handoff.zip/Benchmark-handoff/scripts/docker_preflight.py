import json,subprocess,sys,os,ast
from pathlib import Path
from study_code_harness_v2 import score_code,policy
P=Path(__file__).resolve().parents[1];owner=P.stat();out=P/'environment/docker_preflight.json'
pinned=(P/'environment/docker_image_digest.txt').read_text().strip()
subprocess.run(['docker','pull',pinned],check=True)
image=pinned
(P/'environment/docker_image_digest.txt').write_text(image)
keys=json.loads((P/'datasets/study_v2/private/answer_keys.json').read_text());results=[]
for id,k in keys.items():
 if id.startswith('COD'):
  r=score_code(k['reference_code'],id,k['expected']['cases'],image);assert r['correct'],(id,r);results.append({'id':id,'status':r['status'],'cases':r['total']})
probes=[('wrong','def solve(x): return 999',[{'input':[],'expected':0}],False),('timeout','def solve(x):\n while True:pass',[{'input':[],'expected':0}],False),('ord','def solve(x):return ord(x)',[{'input':'A','expected':65}],True),('constant_annotations','N=65\ndef solve(x: str)->int:return N',[{'input':'A','expected':65}],True),('recursive','def solve(n):return 1 if n<=1 else n*solve(n-1)',[{'input':5,'expected':120}],True),('builtin_set','def solve(x):return [chr(65),list(divmod(7,3)),pow(2,3),len(frozenset([1,1]))]',[{'input':None,'expected':['A',[2,1],8,1]}],True)]
for name,code,cases,expected in probes:
 r=score_code(code,'PILOT',cases,image);assert r['correct']==expected,(name,r);results.append({'probe':name,'result':r})
# Verify actual isolation, limits and unprivileged identity from INSIDE the same sandbox flags.
script='''import os,socket,json
r={"uid":os.getuid(),"network_interfaces":os.listdir("/sys/class/net"),"memory_max":open("/sys/fs/cgroup/memory.max").read().strip(),"cpu_max":open("/sys/fs/cgroup/cpu.max").read().strip(),"pids_max":open("/sys/fs/cgroup/pids.max").read().strip(),"cap_eff":next(l.strip() for l in open("/proc/self/status") if l.startswith("CapEff:")),"no_new_privs":next(l.strip() for l in open("/proc/self/status") if l.startswith("NoNewPrivs:"))}
try:open("/forbidden-write","w");r["root_readonly"]=False
except OSError:r["root_readonly"]=True
print(json.dumps(r))'''
cmd=['docker','run','--rm','--network','none','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges','--memory','256m','--memory-swap','256m','--cpus','1','--pids-limit','32','--user','65534:65534',image,'python','-c',script]
isolation=json.loads(subprocess.check_output(cmd));assert isolation['uid']==65534 and isolation['root_readonly'];assert isolation['network_interfaces']==['lo'];assert isolation['memory_max']=='268435456';assert isolation['pids_max']=='32';assert isolation['cap_eff'].endswith('0000000000000000');assert isolation['no_new_privs'].endswith('1')
left=subprocess.check_output(['docker','ps','-a','--filter','name=study-v2-','--format','{{.Names}}']).decode().strip();assert not left,left
out.write_text(json.dumps({'image':image,'results':results,'isolation':isolation,'leftover_containers':left,'status':'passed'},indent=2)+'\n')
for f in [out,P/'environment/docker_image_digest.txt']:os.chown(f,owner.st_uid,owner.st_gid)
print('Docker preflight PASSED:',image,flush=True)
