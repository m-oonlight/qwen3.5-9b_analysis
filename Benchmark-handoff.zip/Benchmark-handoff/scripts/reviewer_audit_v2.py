from pathlib import Path
_ROOT=Path(__file__).resolve().parents[1]
#!/usr/bin/env python3
"""
Independent audit of Study v2. Standard library only; no model involved.

  1. Recompute all 60 answers from the PUBLIC prompts with logic written from
     scratch (not the author's regex parsers), and compare with the private keys.
  2. Run plausible wrong programs against the FULL hidden case set in
     answer_keys.json (not the author's 11 mutants), to see what the 400+
     cases per task actually reject.
  3. Report, per wrong program, whether the hidden cases kill it and the first
     case that does.
"""
import copy, itertools, json, re
from fractions import Fraction as Fr

BUNDLE = str(_ROOT/"datasets/study_v2")
TASKS = json.load(open(f"{BUNDLE}/public/tasks.json"))
KEYS = json.load(open(f"{BUNDLE}/private/answer_keys.json"))
PROMPT = {t["id"]: t["prompt"] for t in TASKS}
FAMILY = {t["id"]: t["family"] for t in TASKS}
CAT = {t["id"]: t["category"] for t in TASKS}


def same(e, a):
    if type(e) is not type(a):
        return False
    if isinstance(e, dict):
        return e.keys() == a.keys() and all(same(e[k], a[k]) for k in e)
    if isinstance(e, list):
        return len(e) == len(a) and all(same(x, y) for x, y in zip(e, a))
    return e == a


def frac(x):
    x = Fr(x)
    return {"numerator": x.numerator, "denominator": x.denominator}


# ---------------------------------------------------------------------------
# 1. Independent recomputation from the public prompt text
# ---------------------------------------------------------------------------
def ints(pattern, text, cast=int):
    return [cast(g) for g in re.search(pattern, text).groups()]


def jload(text, start, end):
    return json.loads(text.split(start)[1].split(end)[0])


def recompute(tid):
    q = PROMPT[tid]
    fam = FAMILY[tid]
    if fam == "group_discount":
        packs, size = ints(r"(\d+) packs each contain (\d+)", q)
        n = packs * size
        pooled = (n // 3) * 2 + n % 3
        per_pack = packs * ((size // 3) * 2 + size % 3)
        ans = {"cost": pooled}
        note = "" if "grouped together" in q else f"AMBIGUOUS pooled={pooled} per-pack={per_pack}"
        return ans, note
    if fam == "mixture":
        c0 = int(re.search(r"concentration (\d+)%", q)[1])
        water = int(re.search(r"Adding (\d+) litres", q)[1])
        num, den = ints(r"exactly (\d+)/(\d+) percent", q)
        c1 = Fr(num, den)  # percent
        v = c1 * water / (Fr(c0) - c1)
        assert Fr(c0) * v == c1 * (v + water)
        return frac(v), ""
    if fam == "knapsack":
        w = jload(q, "Weights: ", ";")
        vals = json.loads(re.search(r"values: (\[.*?\])", q)[1])
        cap = int(re.search(r"capacity: (\d+)", q)[1])
        best = max(sum(v for v, b in zip(vals, m) if b)
                   for m in itertools.product((0, 1), repeat=len(w))
                   if sum(x for x, b in zip(w, m) if b) <= cap)
        greedy = 0
        load = 0
        for i in sorted(range(len(w)), key=lambda i: -Fr(vals[i], w[i])):
            if load + w[i] <= cap:
                load += w[i]
                greedy += vals[i]
        return {"value": best}, ("greedy-safe" if greedy == best else f"greedy={greedy}<opt={best}")
    if fam == "combinatorics":
        n = int(re.search(r"length (\d+)", q)[1])
        want3 = "exactly three" in q
        c = 0
        for bits in itertools.product((0, 1), repeat=n):
            if any(bits[i] == bits[i + 1] == 1 for i in range(n - 1)):
                continue
            if want3 and sum(bits) != 3:
                continue
            c += 1
        return {"count": c}, ""
    if fam == "linear_system":
        total = int(re.search(r"sold (\d+) drinks", q)[1])
        rev = int(re.search(r"revenue was (\d+)", q)[1])
        sols = [(l, total - l) for l in range(total + 1) if 3 * l + 2 * (total - l) == rev]
        return {"large": sols[0][0], "small": sols[0][1]}, ("unique" if len(sols) == 1 else f"{len(sols)} sols")
    if fam == "scheduling":
        jobs = json.loads(re.search(r"take (\[.*?\])", q)[1])
        best = min(max(sum(j for j, b in zip(jobs, m) if b), sum(j for j, b in zip(jobs, m) if not b))
                   for m in itertools.product((0, 1), repeat=len(jobs)))
        return {"minutes": best}, ""
    if fam == "probability":
        r, b, w = ints(r"(\d+) red, (\d+) blue and (\d+) white", q)
        bag = "R" * r + "B" * b + "W" * w
        pairs = list(itertools.combinations(bag, 2))
        f = Fr(sum(x == y for x, y in pairs), len(pairs))
        return frac(f), ""
    if fam == "modular_constraints":
        lo, hi = ints(r"\[(\d+),(\d+)\]", q)
        rem, mod = ints(r"remainder (\d+) when divided by (\d+)", q)
        ndiv = int(re.search(r"not divisible by (\d+)", q)[1])
        hit = next((x for x in range(lo, hi + 1) if x % mod == rem and x % ndiv != 0), None)
        return {"number": hit}, ""
    if fam == "percentage_composition":
        base, inc, dec = ints(r"price is (\d+).*increases by (\d+)%.*decreases by (\d+)%", q)
        f = Fr(base) * (1 + Fr(inc, 100)) * (1 - Fr(dec, 100))
        return frac(f), ""
    if fam == "constraint_enumeration":
        total = int(re.search(r"a\+b\+c=(\d+)", q)[1])
        prod = int(re.search(r"a\*b=(\d+)", q)[1])
        dm = re.search(r"c-a=(-?\d+)", q)
        trips = [list(t) for t in itertools.permutations(range(1, 10), 3)
                 if sum(t) == total and t[0] * t[1] == prod and (dm is None or t[2] - t[0] == int(dm[1]))]
        return {"triples": sorted(trips)}, (f"{len(trips)} triple(s)")
    if fam == "filtered_aggregation":
        rows = jload(q, "Records: ", ". Sum")
        hit = [r for r in rows if r["group"] == "A" and r["status"] == "paid"]
        return {"total": sum(r["units"] * r["price"] for r in hit), "count": len(hit)}, ""
    if fam == "join":
        customers = jload(q, "Customers: ", ". Orders")
        orders = jload(q, "Orders: ", ". Sum")
        north = {c["id"] for c in customers if c["region"] == "north"}
        return {"total": sum(o["amount"] for o in orders if o["customer"] in north)}, ""
    if fam == "latest_record":
        rows = jload(q, "Events: ", ". Keep")
        best = {}
        for r in rows:
            if r["entity"] not in best or r["time"] > best[r["entity"]]["time"]:
                best[r["entity"]] = r
        last = {r["entity"]: r["id"] for r in rows}
        ans = {"ids": sorted(r["id"] for r in best.values())}
        return ans, ("last-occ-safe" if sorted(last.values()) == ans["ids"] else "last-occ differs (good)")
    if fam == "median":
        xs = sorted(jload(q, "Values: ", ". Return"))
        return {"median": xs[len(xs) // 2]}, ""
    if fam == "weighted_mean":
        rows = jload(q, "Rows: ", ". Compute")
        f = Fr(sum(r["score"] * r["weight"] for r in rows), sum(r["weight"] for r in rows))
        return frac(f), ""
    if fam == "interval_union":
        rows = jload(q, "minutes: ", ". Each")
        covered = set()
        for a, b in rows:
            covered |= set(range(a, b))
        span = max(b for _, b in rows) - min(a for a, _ in rows)
        return {"duration": len(covered)}, ("span-safe" if span == len(covered) else "span differs (good)")
    if fam == "ledger":
        start = int(re.search(r"inventory: (\d+)", q)[1])
        deltas = jload(q, "changes: ", ". Apply")
        levels = [start]
        for d in deltas:
            levels.append(levels[-1] + d)
        return {"final": levels[-1], "minimum": min(levels)}, ("interior-min" if min(levels) != start else "min-at-start")
    if fam == "distinct_entities":
        logs = jload(q, "Logs: ", ". Which")
        return {"users": sorted({l["user"] for l in logs if l["action"] == "write" and l["status"] == "error"})}, ""
    if fam == "ranking_tiebreak":
        rows = jload(q, "Rows: ", ". Rank")
        order = sorted(rows, key=lambda r: (-(2 * r["a"] + r["b"]), r["id"]))
        scores = [2 * r["a"] + r["b"] for r in rows]
        ids = [r["id"] for r in order]
        return {"top": ids[0], "ids": ids}, ("has-tie" if len(set(scores)) < len(scores) else "no-tie")
    if fam == "record_diff":
        old = jload(q, "Old snapshot: ", ". New")
        new = jload(q, "New snapshot: ", ". Return")
        return {"added": sorted(k for k in new if k not in old),
                "removed": sorted(k for k in old if k not in new),
                "changed": sorted(k for k in old & new.keys() if old[k] != new[k])}, ""
    # instruction family: compute directly from the prompt text
    if tid == "INS-01":
        v = [3, 8, 3, 1, 8, 5][:4]
        v = list(dict.fromkeys(v))
        v = [x for x in v if x % 2]
        return {"values": v, "count": len(v)}, "order-dependent"
    if tid == "INS-02":
        words = ["red", "Red", "blue", "red", "BLUE"]
        return {"words": list(dict.fromkeys(w for w in words if w.islower()))}, ""
    if tid == "INS-03":
        recs = [{"id": "A", "score": 2}, {"id": "B", "score": 1}, {"id": "C", "score": 2}]
        return {"ids": [r["id"] for r in sorted(recs, key=lambda r: r["score"])]}, ""
    if tid == "INS-04":
        d = {"a": None, "b": 0, "c": False}
        return {"present": sorted(d), "missing": [k for k in "abcd" if k not in d]}, ""
    if tid == "INS-05":
        vals = [-2, 0, 1, 4, 5, 8]
        kept = [x for x in vals if 0 <= x < 5]
        return {"kept": kept, "rejected_count": len(vals) - len(kept)}, ""
    if tid == "INS-06":
        return {"id": "R17", "length": 3}, ""
    if tid == "INS-07":
        return {"ok": False, "items": [], "reason": None}, ""
    if tid == "INS-08":
        h, m = divmod(125, 60)
        return {"hours": h, "minutes": m}, ""
    if tid == "INS-09":
        return {"values": sorted(["b2", "b10", "a3", "a1"])}, ""
    if tid == "INS-10":
        keep = [x for x in range(1, 13) if x % 3 == 0 and x % 2 != 0]
        sq = sorted((x * x for x in keep), reverse=True)
        return {"squares": sq, "sum": sum(sq)}, ""
    raise ValueError(tid)


def section_recompute():
    print("=== 1. Independent recomputation vs private keys (non-coding) ===")
    bad = []
    notes = []
    for tid in sorted(PROMPT):
        if CAT[tid] == "coding":
            continue
        ans, note = recompute(tid)
        key = KEYS[tid]["expected"]
        if not same(key, ans):
            bad.append((tid, key, ans))
        if note:
            notes.append(f"  {tid}: {note}")
    print(f"  {50 - len(bad)}/50 match")
    for tid, key, ans in bad:
        print(f"  MISMATCH {tid}: key={key} mine={ans}")
    print("  structural notes:")
    print("\n".join(notes))


# ---------------------------------------------------------------------------
# 2. Wrong programs vs the FULL hidden case set
# ---------------------------------------------------------------------------
def load_solve(src):
    ns = {}
    exec(src, ns)
    return ns["solve"]


REFS = {tid: load_solve(KEYS[tid]["reference_code"]) for tid in KEYS if tid.startswith("COD")}


def list_ids(o, acc=None):
    acc = set() if acc is None else acc
    if isinstance(o, list):
        acc.add(id(o))
        for v in o:
            list_ids(v, acc)
    elif isinstance(o, dict):
        for v in o.values():
            list_ids(v, acc)
    return acc


def run_hidden(fn, tid):
    """Return (killed, first_reason) over the full hidden case set, applying the
    harness's own checks: value, input mutation, and COD-05 output aliasing."""
    for i, c in enumerate(KEYS[tid]["expected"]["cases"]):
        arg = copy.deepcopy(c["input"])
        before = copy.deepcopy(arg)
        try:
            out = fn(arg)
        except Exception as e:  # noqa: BLE001
            return True, f"case {i}: {type(e).__name__}"
        if arg != before:
            return True, f"case {i}: input mutation"
        if tid == "COD-05" and isinstance(arg, dict) and out is arg.get("values"):
            return True, f"case {i}: output alias"
        norm = json.loads(json.dumps(out))
        if not same(c["expected"], norm):
            return True, f"case {i}: wrong value {c['input']!r}"
    return False, "SURVIVES all hidden cases"


# wrong programs keyed by task; each (name, source)
WRONG = {
    "COD-01": [
        ("end=b not max", "def solve(iv):\n out=[]\n for a,b in sorted(iv):\n  if out and a<=out[-1][1]:out[-1][1]=b\n  else:out.append([a,b])\n return out"),
        ("strict overlap a<end", "def solve(iv):\n out=[]\n for a,b in sorted(iv):\n  if out and a<out[-1][1]:out[-1][1]=max(out[-1][1],b)\n  else:out.append([a,b])\n return out"),
        ("merge int-adjacent c<=b+1", "def solve(iv):\n out=[]\n for a,b in sorted(iv):\n  if out and a<=out[-1][1]+1:out[-1][1]=max(out[-1][1],b)\n  else:out.append([a,b])\n return out"),
        ("sorts input in place", "def solve(iv):\n iv.sort()\n out=[]\n for p in iv:\n  if out and p[0]<=out[-1][1]:out[-1][1]=max(out[-1][1],p[1])\n  else:out.append(p)\n return out"),
    ],
    "COD-02": [
        ("counts only, ignores order", "def solve(s):\n c=0\n for ch in s:\n  if ch in '([{':c+=1\n  elif ch in ')]}':\n   c-=1\n   if c<0:return False\n return c==0"),
        ("also matches <>", "def solve(s):\n st=[];p={')':'(',']':'[','}':'{','>':'<'}\n for c in s:\n  if c in '([{<':st.append(c)\n  elif c in p:\n   if not st or st.pop()!=p[c]:return False\n return not st"),
    ],
    "COD-03": [
        ("case-insensitive", "def solve(s):\n s=s.lower();return next((i for i,c in enumerate(s) if s.count(c)==1),-1)"),
        ("forward-only duplicate check", "def solve(s):\n return next((i for i,c in enumerate(s) if c not in s[i+1:]),-1)"),
    ],
    "COD-04": [
        ("max frequency", "def solve(xs):\n return max([xs.count(x) for x in xs] or [0])"),
        ("number of runs", "def solve(xs):\n return sum(1 for i,x in enumerate(xs) if i==0 or x!=xs[i-1])"),
        ("forgets final run", "def solve(xs):\n if not xs:return 0\n best=run=1\n for i in range(1,len(xs)):\n  if xs[i]==xs[i-1]:run+=1\n  else:best=max(best,run);run=1\n return best"),
    ],
    "COD-05": [
        ("no k%n", "def solve(d):\n xs=d['values'];k=d['k']\n return xs[-k:]+xs[:-k] if k else xs[:]"),
        ("returns input list at k=0", "def solve(d):\n xs=d['values'];k=d['k']%len(xs) if d['values'] else 0\n return xs[-k:]+xs[:-k] if k else d['values']"),
        ("rotates in place", "def solve(d):\n xs=d['values']\n if not xs:return xs\n for _ in range(d['k']%len(xs)):xs.insert(0,xs.pop())\n return xs"),
    ],
    "COD-06": [
        ("discovery order", "def solve(d):\n xs=d['values'];t=d['target'];seen={};out=[]\n for j,x in enumerate(xs):\n  for i in seen.get(t-x,[]):out.append([i,j])\n  seen.setdefault(x,[]).append(j)\n return out"),
        ("i<=j allows self", "def solve(d):\n xs=d['values'];t=d['target']\n return [[i,j] for i in range(len(xs)) for j in range(i,len(xs)) if xs[i]+xs[j]==t]"),
    ],
    "COD-07": [
        ("case-insensitive runs", "def solve(s):\n out=[]\n for c in s:\n  if out and out[-1][0].lower()==c.lower():out[-1][1]+=1\n  else:out.append([c,1])\n return out"),
        ("total counts", "def solve(s):\n out=[]\n for c in s:\n  for it in out:\n   if it[0]==c:it[1]+=1;break\n  else:out.append([c,1])\n return out"),
    ],
    "COD-08": [
        ("ignores blocked start", "def solve(g):\n if not g or not g[0]:return 0\n R,C=len(g),len(g[0])\n if g[-1][-1]:return 0\n dp=[[0]*C for _ in range(R)];dp[0][0]=1\n for i in range(R):\n  for j in range(C):\n   if (i,j)==(0,0) or g[i][j]:continue\n   dp[i][j]=(dp[i-1][j] if i else 0)+(dp[i][j-1] if j else 0)\n return dp[-1][-1]"),
        ("first-row block not propagated", "def solve(g):\n if not g or not g[0]:return 0\n R,C=len(g),len(g[0])\n if g[0][0] or g[-1][-1]:return 0\n dp=[[0]*C for _ in range(R)]\n for j in range(C):dp[0][j]=0 if g[0][j] else 1\n for i in range(R):dp[i][0]=0 if g[i][0] else 1\n for i in range(1,R):\n  for j in range(1,C):dp[i][j]=0 if g[i][j] else dp[i-1][j]+dp[i][j-1]\n return dp[-1][-1]"),
        ("mutates grid in place", "def solve(g):\n if not g or not g[0] or g[0][0]:return 0\n for i in range(len(g)):\n  for j in range(len(g[0])):\n   if g[i][j]:g[i][j]=0\n   elif i==0 and j==0:g[i][j]=1\n   else:g[i][j]=(g[i-1][j] if i else 0)+(g[i][j-1] if j else 0)\n return g[-1][-1]"),
    ],
    "COD-09": [
        ("DFS first path length", "def solve(d):\n adj=[[] for _ in range(d['n'])]\n for a,b in d['edges']:adj[a].append(b);adj[b].append(a)\n def dfs(x,seen):\n  if x==d['goal']:return 0\n  for y in adj[x]:\n   if y not in seen:\n    z=dfs(y,seen|{y})\n    if z>=0:return z+1\n  return -1\n return dfs(d['start'],{d['start']})"),
        ("directed only", "def solve(d):\n adj=[[] for _ in range(d['n'])]\n for a,b in d['edges']:adj[a].append(b)\n q=[d['start']];dist={d['start']:0}\n for x in q:\n  if x==d['goal']:return dist[x]\n  for y in adj[x]:\n   if y not in dist:dist[y]=dist[x]+1;q.append(y)\n return -1"),
    ],
    "COD-10": [
        ("FIFO Kahn (not lexicographic)", "def solve(d):\n n=d['n'];adj=[[] for _ in range(n)];ind=[0]*n\n for a,b in d['edges']:adj[a].append(b);ind[b]+=1\n q=[i for i in range(n) if ind[i]==0];out=[]\n for x in q:\n  out.append(x)\n  for y in adj[x]:\n   ind[y]-=1\n   if ind[y]==0:q.append(y)\n return out if len(out)==n else None"),
        ("ignores self-loops", "def solve(d):\n n=d['n'];edges=[e for e in d['edges'] if e[0]!=e[1]];rem=set(range(n));out=[]\n while rem:\n  ready=[x for x in rem if not any(b==x and a in rem for a,b in edges)]\n  if not ready:return None\n  x=min(ready);out.append(x);rem.remove(x)\n return out"),
        ("any valid order via DFS", "def solve(d):\n n=d['n'];adj=[[] for _ in range(n)];st=[0]*n;order=[]\n for a,b in d['edges']:adj[a].append(b)\n def vis(x):\n  if st[x]==1:raise ValueError\n  if st[x]==2:return\n  st[x]=1\n  for y in adj[x]:vis(y)\n  st[x]=2;order.append(x)\n try:\n  for v in range(n):vis(v)\n except ValueError:return None\n return order[::-1]"),
    ],
}


def section_wrong():
    print("\n=== 2. Wrong programs vs the full hidden case set ===")
    survivors = []
    for tid in sorted(WRONG):
        n = len(KEYS[tid]["expected"]["cases"])
        print(f"\n  {tid} ({n} hidden cases):")
        # sanity: the reference itself passes every hidden case
        ref_killed, _ = run_hidden(REFS[tid], tid)
        print(f"    reference passes all hidden cases: {not ref_killed}")
        for name, src in WRONG[tid]:
            killed, why = run_hidden(load_solve(src), tid)
            tag = "killed" if killed else "*** SURVIVES ***"
            print(f"    [{tag}] {name}: {why}")
            if not killed:
                survivors.append((tid, name))
    print("\n  Wrong programs that survive the hidden cases:",
          survivors if survivors else "none")
    return survivors


if __name__ == "__main__":
    section_recompute()
    section_wrong()