"""Run audited study or independent calibration; model code executes only in Docker."""
import argparse,fcntl,datetime,hashlib,json,os,random,subprocess,threading,time,urllib.request
from pathlib import Path
from study_score_v2 import score_final
from study_code_harness_v2 import score_code
P=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--quant',default='Q8_0');p.add_argument('--pilot',action='store_true');p.add_argument('--repetitions',type=int,default=3);a=p.parse_args()
lock=(P/'environment/study_runner.lock').open('a');os.chown(P/'environment/study_runner.lock',P.stat().st_uid,P.stat().st_gid)
try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
except BlockingIOError:raise SystemExit('Another study runner is active')
c=json.loads((P/'config/experiment.json').read_text());base=c['server_url']
if a.quant not in c['quantizations'] or a.repetitions<1:raise SystemExit('Invalid quantization or repetitions')
props=json.load(urllib.request.urlopen(base+'/props',timeout=10))
if props['default_generation_settings']['n_ctx']!=c['context_tokens']:raise SystemExit('Context mismatch')
if Path(props['model_path']).name!=f'Qwen_Qwen3.5-9B-{a.quant}.gguf':raise SystemExit('Loaded model mismatch')
server_commands=[]
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit():continue
 try:
  cmd=proc.joinpath('cmdline').read_bytes().decode().split('\0');cmd=[x for x in cmd if x]
  if cmd and Path(cmd[0]).name=='llama-server' and '-m' in cmd and Path(cmd[cmd.index('-m')+1]).name==Path(props['model_path']).name:server_commands.append(cmd)
 except (OSError,UnicodeError,ValueError):pass
if len(server_commands)!=1:raise SystemExit('Cannot uniquely verify server command')
server_command=server_commands[0]
for flag,value in [('--gpu-layers','all'),('--fit','off'),('--override-tensor','token_embd.weight=CUDA0'),('-ctk',c['kv_cache_type_k']),('-ctv',c['kv_cache_type_v']),('-b',str(c['batch_tokens'])),('-ub',str(c['ubatch_tokens'])),('--parallel',str(c['parallel_sequences'])),('--reasoning','on')]:
 if flag not in server_command or server_command[server_command.index(flag)+1]!=value:raise SystemExit('Server configuration mismatch: '+flag)

image=(P/'environment/docker_image_digest.txt').read_text().strip()
subprocess.run(['docker','image','inspect',image],check=True,stdout=subprocess.DEVNULL)
if not a.pilot:
 downloads=json.loads((P/'environment/quantization_downloads.json').read_text())
 if any(x['status'] in ('downloading','verifying') for x in downloads['files']):raise SystemExit('Wait for model downloads to finish before keeping benchmark timing.')
if a.pilot:
 tasks=json.loads((P/'datasets/calibration_v2.json').read_text());keys={t['id']:t['key'] for t in tasks};reps=1
else:
 subprocess.run([os.sys.executable,str(P/'scripts/validate_study_v2.py')],check=True)
 tasks=json.loads((P/'datasets/study_v2/public/tasks.json').read_text());keys=json.loads((P/'datasets/study_v2/private/answer_keys.json').read_text());reps=a.repetitions
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');folder=P/'raw_results'/f'study_v2_{a.quant}_{"pilot" if a.pilot else "full"}_{stamp}';folder.mkdir();os.chown(folder,P.stat().st_uid,P.stat().st_gid)
owner=P.stat()
def save(path,value):
 path.write_text(json.dumps(value,indent=2)+'\n');os.chown(path,owner.st_uid,owner.st_gid)
meta={'purpose':'calibration, excluded from study' if a.pilot else 'study','config':c,'repetitions':reps,'server_props':props,'server_command':server_command,'docker_image':image,'task_sha256':hashlib.sha256(json.dumps(tasks,sort_keys=True).encode()).hexdigest(),'seed_policy':'73191 + trial index; same shuffled task order across quantizations','gpu_memory':'whole-device MiB sampled every second; includes desktop and other processes','timing':'generation time excludes Docker scoring; throughput from server timings when supplied','context_note':'fixed capacity, actual prompt lengths vary; speed is task-dependent'}
save(folder/'metadata.json',meta);print('Results:',folder,flush=True)
manifest=json.loads((P/'environment/quantization_downloads.json').read_text());entry=next(x for x in manifest['files'] if x['quantization']==a.quant)
if entry.get('status')!='verified':raise SystemExit('Model has no verified download record')
meta['model_provenance']=entry;meta['gguf_repository_revision']=manifest['revision'];save(folder/'metadata.json',meta)
rows=[]
for rep in range(reps):
 order=list(tasks);random.Random(c['seed']+rep).shuffle(order)
 for task in order:
  id=task['id'];params={k:c[k] for k in ['temperature','top_p','top_k','min_p','presence_penalty']};params.update(seed=c['seed']+rep,max_tokens=c['max_output_tokens'],stream=True,stream_options={'include_usage':True},cache_prompt=False,messages=[{'role':'user','content':task['prompt']}])
  params['reasoning_budget_tokens']=c.get('reasoning_budget_tokens',-1)
  row={'id':id,'category':task['category'],'trial':rep+1,'quantization':a.quant,'request':params};samples=[];stop=threading.Event()
  def monitor():
   while not stop.is_set():
    try:samples.append({'elapsed':time.monotonic()-start,'memory_mib':int(subprocess.check_output(['nvidia-smi','--query-gpu=memory.used','--format=csv,noheader,nounits'],text=True,timeout=3).strip())})
    except Exception:pass
    stop.wait(1)
  start=time.monotonic();thread=threading.Thread(target=monitor,daemon=True);thread.start();content=[];reason=[];finish=None;usage={};timings={};done=False;first=None
  print(f'Trial {rep+1}: {id}',flush=True)
  live=folder/f'{rep+1}_{id}.live.txt'
  try:
   req=urllib.request.Request(base+'/v1/chat/completions',data=json.dumps(params).encode(),headers={'Content-Type':'application/json'})
   with urllib.request.urlopen(req,timeout=c['request_timeout_seconds']) as response,live.open('w',buffering=1) as f:
    f.write(task['prompt']+'\n\n');section=None
    for raw in response:
     line=raw.decode().strip()
     if not line.startswith('data:'):continue
     data=line[5:].strip()
     if data=='[DONE]':done=True;break
     chunk=json.loads(data)
     if 'error' in chunk:raise RuntimeError(str(chunk['error']))
     usage=chunk.get('usage') or usage;timings=chunk.get('timings') or timings
     for choice in chunk.get('choices',[]):
      finish=choice.get('finish_reason') or finish;delta=choice.get('delta',{})
      for field,bucket in [('reasoning_content',reason),('content',content)]:
       value=delta.get(field)
       if value:
        if first is None:first=time.monotonic()-start
        if section!=field:f.write('\n\n'+field.upper()+':\n');section=field
        bucket.append(value);f.write(value)
   if not done or not finish:raise RuntimeError('Incomplete response stream')
   row.update(content=''.join(content),reasoning_content=''.join(reason),finish_reason=finish,usage=usage,timings=timings)
   row['generation_seconds']=time.monotonic()-start
   row['end_to_end_completion_tokens_per_second']=usage.get('completion_tokens',0)/row['generation_seconds']
   row['decode_tokens_per_second']=timings.get('predicted_per_second')
   row['prompt_tokens_per_second']=timings.get('prompt_per_second')
   result=score_final(row['content'],keys[id],task['category'],finish)
   if task['category']=='coding' and 'code' in result:
    execution=score_code(result['code'],id,keys[id]['expected']['cases'],image);result['execution']=execution;result['answer_correct']=execution['correct'];result['correct']=None if execution['correct'] is None else bool(result['format_ok'] and execution['correct']);result['status']=execution['status'] if result['format_ok'] else result['status']
   row['score']=result
  except Exception as e:row.update(error=type(e).__name__+': '+str(e),generation_seconds=time.monotonic()-start,score={'correct':None,'status':'infrastructure_error'})
  finally:stop.set();thread.join(timeout=4)
  row.update(first_token_seconds=first,gpu_samples=samples,peak_whole_gpu_mib=max((s['memory_mib'] for s in samples),default=None));save(folder/f'{rep+1}_{id}.json',row);rows.append(row)
  if live.exists():os.chown(live,owner.st_uid,owner.st_gid)
  summary={'completed':len(rows),'planned':len(tasks)*reps,'correct':sum(r['score'].get('correct') is True for r in rows),'truncated':sum(r.get('finish_reason')=='length' for r in rows),'infrastructure_errors':sum(r['score'].get('correct') is None for r in rows),'generation_seconds':sum(r['generation_seconds'] for r in rows),'complete':len(rows)==len(tasks)*reps}
  save(folder/'summary.json',summary);print(id,row['score']['status'],round(row['generation_seconds'],1),'seconds',flush=True)
os.chown(folder,owner.st_uid,owner.st_gid)
print(json.dumps(summary),flush=True)
