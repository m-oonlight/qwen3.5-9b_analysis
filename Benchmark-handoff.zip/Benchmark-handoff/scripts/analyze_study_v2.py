"""Summarize study results and create a final-answer review page."""
import argparse,collections,html,json,statistics
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('run');a=p.parse_args();folder=Path(a.run).resolve();rows=[json.loads(p.read_text()) for p in sorted(folder.glob('[123]_*.json'))];meta=json.loads((folder/'metadata.json').read_text());groups=collections.defaultdict(list)
for r in rows:groups[r['category']].append(r)
summary={}
for cat,rs in groups.items():
 times=[r['generation_seconds'] for r in rs];summary[cat]={'attempts':len(rs),'primary_correct':sum(r['score'].get('correct') is True for r in rs),'substantive_correct':sum(r['score'].get('answer_correct') is True for r in rs),'statuses':dict(collections.Counter(r['score']['status'] for r in rs)),'mean_generation_seconds':statistics.mean(times),'completion_tokens':sum(r.get('usage',{}).get('completion_tokens',0) for r in rs),'peak_whole_gpu_mib':max((r.get('peak_whole_gpu_mib') or 0 for r in rs),default=0)}
(folder/'analysis.json').write_text(json.dumps(summary,indent=2)+'\n')
parts=['<!doctype html><meta charset="utf-8"><title>Study answer review</title><style>body{max-width:1000px;margin:30px auto;font:16px system-ui}pre{white-space:pre-wrap;background:#f4f4f4;padding:16px}article{border-top:1px solid #ccc;padding:20px 0}</style><h1>Study answer review</h1><p>Reasoning is generated text, not a record of all internal computation. Deterministic scoring remains primary. Calibration attempts are excluded from the study.</p><pre>'+html.escape(json.dumps(summary,indent=2))+'</pre>']
for r in rows:
 parts+=['<article><h2>'+html.escape(f"{r['id']} · trial {r['trial']} · {r['score']['status']}")+'</h2><h3>Prompt</h3><pre>'+html.escape(r['request']['messages'][0]['content'])+'</pre><h3>Final answer</h3><pre>'+html.escape(r.get('content',''))+'</pre><details><summary>Scoring details</summary><pre>'+html.escape(json.dumps(r['score'],indent=2))+'</pre></details><details><summary>Generated reasoning</summary><pre>'+html.escape(r.get('reasoning_content',''))+'</pre></details></article>']
(folder/'review.html').write_text(''.join(parts));print(json.dumps(summary,indent=2))
