# Current revision: v2.1

See AUDIT_FOLLOWUP.md for changed constant/annotation/builtin policy. Older policy statements below are historical where superseded. Bundle layout now matches project layout.

# Study v2: objective validation and calibration candidate

The audit summary was supplied; its referenced suite_audit.py and additional_coding_tests.json were NOT attached. This revision reproduces checks with our own code; it does not assert that Claude executed the claimed tests.

60 tasks remain: 20 reasoning, 20 data, 10 instruction, 10 coding. v1 is preserved. Public prompts and private keys are separate. Never put reference/fixture files into the tested model context.

## What changed

See CHANGELOG.json for every task ID. Clarified key names, pooling, record counts and output contracts. Added explicit drink questions. Replaced structurally weak instances with greedy counterexamples, multiple solutions, null, shuffled events, disjoint intervals, interior minima, ties, varied diffs and order-dependent operations. Removed uncalibrated difficulty labels. Coding now uses FINAL_CODE plus a Python fence, not JSON string escaping, and has explicit bounds and policy constraints.

## Direct reference validation

scripts/build_study_v2.py contains separate implementations for all ten coding algorithms and recomputes every noncoding answer from the v2 prompt. Coding references agree with independent oracles on 400 random cases per task, targeted edge cases and a boundary-size case per task. There are 4076 coding cases total. This is finite validation, not proof of program correctness on all inputs. Math/data/instruction correctness is grounded in exact rational arithmetic, enumeration and specified deterministic rules. Fresh instances and familiar patterns do NOT establish zero contamination.

Run: python3 scripts/validate_study_v2.py

This checks dataset hashes, all references and 4076 fixtures, scorer regressions, and rejection of 11 known wrong programs. It deliberately executes only authored reference/mutant code locally; NEVER use this validator to execute model code on the host.

## Scoring

scripts/study_score_v2.py accepts either a full key record or a bare expected object. Separate fields report answer_correct, schema_ok, format_ok, field_scores, failures and primary correct. Numeric strings/integral floats can be numerically equivalent but fail schema; boolean true does not equal integer 1. Renamed keys are schema failures with unscorable substance, not guessed field mappings. Markdown wrappers may permit secondary substance evaluation but fail the exact final format. Duplicate keys are rejected as ambiguous. Text inside <think> is excluded; non-stop finish reasons and truncated outputs cannot pass. Multiple failure flags may coexist. This preserves distinctions instead of turning every failure into a math error.

The primary objective is success under the declared contract. Substantive correctness is reported separately. Assistant review annotates EVERY final response but cannot override objective scores silently. Disagreements, ambiguity and corrections must be recorded. Evaluate private tests only after the model produces code.

## Execution harness specification

scripts/study_code_harness_v2.py: use a PINNED Python Docker image digest. Every submitted solution runs in a fresh container/process, no networking, read-only root, all capabilities dropped, no privilege escalation, unprivileged UID, 256MiB memory including swap, one CPU, 32 process limit, 10-second CPU limit and 20-second host timeout. Named container is forcibly removed on exit, including timeout. Only a read-only temporary payload and harness are mounted. No model reference answers are supplied during generation.

AST parsing classifies import, top-level, unsafe dynamic/private access, signature/definition and syntax policy violations separately. Only authored functions and a restricted builtin set execute. Every fixture deep-copies input and compares it afterward; rotate additionally checks output object identity against the input list. Results undergo JSON roundtrip and strict type/value equality. Report passed/total fixtures and error categories. Python algorithm imports are forbidden by the prompt; bounds keep simple implementations feasible.

Docker runtime/limits have NOT been integration-tested here. Missing Docker/image means execution_unavailable with correct=null, not a model failure. Harness/infrastructure errors are not scored as model intelligence failures. Before pilot, run all reference solutions AND known wrong programs in the actual pinned container to validate the harness/limits.

## Study decisions still pending

Reasoning policy/output budget and fixed context must be selected by calibration; 8K/6144 still truncated one diagnostic. Full GPU placement at any newly selected context must be verified. Final repetitions, task order, task-level seeds, workload lengths, retry/timeout rules and analysis plan must be frozen before final comparisons. Same seed does NOT guarantee identical random streams or outputs across formats. Prefer paired task-level comparisons and uncertainty that respects repeated trials/families; do not treat 4076 coding fixtures as 4076 independent model generations. Only ten code generations per trial.

One hour per quantization is not established: 60 questions at the observed diagnostic pace would exceed it, and repetitions add time. Speed is measured separately with controlled llama-bench workloads; whole-GPU sampled maxima and llama.cpp buffer allocations are both recorded. Any model-based subjective review is secondary. Public/familiar coding patterns weaken contamination claims.

Publisher-prequantized files share one pinned repository revision but exact common upstream checkpoint and conversion provenance need stronger verification before claiming that weight quantization is the ONLY difference. Strongest design: generate all formats from one F16/BF16 GGUF with one pinned quantizer and imatrix policy. Current downloads are suitable for calibration, conditional on metadata/provenance inspection.

KL divergence/perplexity is optional and requires a higher-precision reference and controlled token corpus; it is not yet implemented. No significance or universal intelligence claim is warranted from 60 tasks.

## Artifact status

Ready for independent audit and calibration preparation. NOT marked ready for final measurement. No v2 model generation has run yet.
