# V2.1 audit follow-up

Executed Claude's supplied scripts after adapting only their paths. All 50 noncoding keys match, all references pass, and all 26 wrong programs are rejected. Files in environment/pre_audit_fix_v2 preserve old prompts/keys/harness/scorer.

F1: expanded the builtin allowlist including ord, chr, divmod, frozenset and pow. Tested a correct ord-based solution through the actual RUNNER. The attached reviewer probe's independent SAFE list still contains its original older names; that local imitation is not a test of our updated RUNNER. test_harness_audit_fixes.py uses the actual current RUNNER.
F2: permits top-level literal constants and postponed type annotations. Corresponding prompts updated. Decorators, nonliteral top-level computation, imports, dynamic execution and private access remain forbidden. Constant/annotation and recursive solutions tested in the actual RUNNER.
F3: bundle now preserves datasets/study_v2 plus scripts/, matching validator paths. Extraction smoke test performed.
DAT-06: added a gap; reference duration changes from 24 to 20. Independently recomputed and reviewer audit rerun.
Coding marker: continues choosing the first complete FINAL_CODE fenced block; this is a defined parser rule, not a search for a passing answer. FINAL_JSON uses the last marker. Multiple-block output is not part of the requested contract.

Validation: all 60 tasks; 4076 fixtures; 13 scorer regressions; 11 built-in mutants; 26 reviewer mutants; actual restricted RUNNER with ten authored references plus ord, constant/annotations and recursion variants.

Docker is not installed here. Network/read-only/capability flags, limits, timeout and container cleanup have NOT been tested in Docker. No final measurement is authorized by this validation alone. Run Docker preflight before a kept coding run; missing infrastructure remains unscored, not a model failure. No model was run for this audit.

The exact builtin allowlist is in the RUNNER source shipped in scripts/study_code_harness_v2.py. This revision changes prompts/harness, so freeze v2.1 hashes before using it. The older build_study_v2.py is a historical v2 generator; it is omitted from this revision's runnable audit bundle to prevent overwriting v2.1.
