"""Deterministic scorer: substantive, schema and presentation results are separate."""
import decimal,json,re

def same(a,b):
 if type(a)!=type(b):return False
 if isinstance(a,dict):return a.keys()==b.keys() and all(same(a[k],b[k]) for k in a)
 if isinstance(a,list):return len(a)==len(b) and all(same(x,y) for x,y in zip(a,b))
 return a==b

def numeric_equal(a,b):
 if type(a)==int and type(b) in (int,float,str):
  try:
   z=decimal.Decimal(str(b));return z.is_finite() and z==decimal.Decimal(a)
  except decimal.InvalidOperation:return False
 if isinstance(a,dict):return isinstance(b,dict) and a.keys()==b.keys() and all(numeric_equal(a[k],b[k]) for k in a)
 if isinstance(a,list):return isinstance(b,list) and len(a)==len(b) and all(numeric_equal(x,y) for x,y in zip(a,b))
 return same(a,b)

def schema(a,b):
 if type(a)!=type(b):return False
 if isinstance(a,dict):return a.keys()==b.keys() and all(schema(a[k],b[k]) for k in a)
 if isinstance(a,list):return isinstance(b,list) and (not a or all(schema(a[0],x) for x in b)) # Cardinality is correctness, element types are schema.
 return True

def final_only(text):
 text=re.sub(r'<think>.*?</think>','',text or '',flags=re.S)
 if '<think>' in text:text=text.split('<think>')[0]
 return text.strip()

def score_final(content,key,category,finish_reason):
 result={'status':None,'correct':False,'answer_correct':None,'schema_ok':False,'format_ok':False,'field_scores':{},'failures':[]}
 if finish_reason!='stop':
  result['status']='truncated' if finish_reason=='length' else 'incomplete_response';result['failures']=[result['status']];return result
 text=final_only(content)
 if not text:result['status']='no_final_answer';result['failures']=[result['status']];return result
 if category=='coding':
  match=re.search(r'FINAL_CODE:\s*```(?:python)?\s*\n(.*?)\n```',text,re.S)
  if match:
   result['code']=match[1];result['schema_ok']=True;result['format_ok']=not text[match.end():].strip();result['status']='needs_isolated_execution' if result['format_ok'] else 'format_failure';result['failures']=[] if result['format_ok'] else ['format_failure']
  else:result['status']='code_format_failure';result['failures']=['code_format_failure']
  return result
 expected=key.get('expected',key) # Accept full answer-key record OR bare expected object.
 marker=text.rfind('FINAL_JSON:');has_marker=marker>=0
 tail=text[marker+len('FINAL_JSON:'):].lstrip() if has_marker else text
 original=tail;wrapped=False
 if tail.startswith('**'):tail=tail[2:].lstrip();wrapped=True
 if tail.startswith('```'):
  m=re.match(r'```(?:json)?\s*\n(.*?)\n```(.*)',tail,re.S)
  if m:tail=m[1]+m[2];wrapped=True
 duplicates=[]
 def pairs_hook(pairs):
  d={}
  for k,v in pairs:
   if k in d:duplicates.append(k)
   d[k]=v
  return d
 try:answer,end=json.JSONDecoder(object_pairs_hook=pairs_hook,parse_constant=lambda x:(_ for _ in ()).throw(ValueError('Non-finite JSON'))).raw_decode(tail)
 except ValueError:result['status']='invalid_json';result['failures']=['invalid_json'];return result
 if duplicates:result['status']='duplicate_keys';result['failures']=['duplicate_keys'];return result
 if not isinstance(answer,dict):result['status']='schema_failure';result['failures']=['schema_failure'];return result
 result['parsed']=answer;result['schema_ok']=schema(expected,answer)
 result['format_ok']=has_marker and not wrapped and not tail[end:].strip()
 if set(answer)==set(expected):
  result['field_scores']={k:numeric_equal(v,answer[k]) for k,v in expected.items()};result['answer_correct']=all(result['field_scores'].values())
 if not result['schema_ok']:result['failures'].append('schema_failure')
 if not result['format_ok']:result['failures'].append('format_failure')
 if result['answer_correct'] is False:result['failures'].append('wrong_answer')
 result['correct']=result['schema_ok'] and result['format_ok'] and result['answer_correct'] is True
 result['status']='correct' if result['correct'] else (result['failures'][0] if result['failures'] else 'unscorable')
 return result
