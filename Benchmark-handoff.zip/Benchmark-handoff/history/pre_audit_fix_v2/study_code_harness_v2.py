"""Execute UNTRUSTED model code only in Docker, never on host."""
import ast,json,subprocess,tempfile,uuid
from pathlib import Path

def policy(code):
 try:tree=ast.parse(code)
 except SyntaxError as e:return 'syntax_error',str(e)
 if any(isinstance(n,(ast.Import,ast.ImportFrom)) for n in ast.walk(tree)):return 'import_policy_failure','Imports are forbidden by task prompt.'
 if not tree.body or any(not isinstance(n,ast.FunctionDef) for n in tree.body):return 'top_level_policy_failure','Only function definitions allowed at module level.'
 for fn in tree.body:
  if fn.decorator_list or fn.returns or any(a.annotation for a in fn.args.args):return 'definition_policy_failure','No decorators or evaluated annotations.'
  for default in fn.args.defaults+ [x for x in fn.args.kw_defaults if x is not None]:
   try:ast.literal_eval(default)
   except (ValueError,TypeError):return 'definition_policy_failure','Defaults must be literals.'
 for n in ast.walk(tree):
  if isinstance(n,ast.Name) and (n.id.startswith('__') or n.id in {'eval','exec','open','compile','globals','locals','getattr','setattr','delattr','vars','input','breakpoint'}):return 'unsafe_code_policy_failure',n.id
  if isinstance(n,ast.Attribute) and n.attr.startswith('_'):return 'unsafe_code_policy_failure',n.attr
 if not any(isinstance(n,ast.FunctionDef) and n.name=='solve' for n in tree.body):return 'missing_function','Missing solve'
 return None,None

RUNNER='''import json,copy,sys,inspect
payload=json.load(open('/task/payload.json'))
safe_names=['abs','all','any','bool','dict','enumerate','filter','float','int','isinstance','len','list','map','max','min','next','range','reversed','round','set','sorted','str','sum','tuple','zip','ValueError','TypeError']
ns={'__builtins__':{k:__builtins__[k] if isinstance(__builtins__,dict) else getattr(__builtins__,k) for k in safe_names}}
try:
 exec(payload['code'],ns)
 fn=ns['solve']
 failures=[];passed=0
 for i,case in enumerate(payload['cases']):
  value=copy.deepcopy(case['input']);before=copy.deepcopy(value)
  try:
   result=fn(value)
   if value!=before:failures.append({'case':i,'status':'input_mutation'});continue
   if payload['task_id']=='COD-05' and result is value['values']:failures.append({'case':i,'status':'output_alias'});continue
   # JSON roundtrip rejects unserializable values and exposes output type mismatches.
   result=json.loads(json.dumps(result,allow_nan=False))
   def same(a,b):
    if type(a)!=type(b):return False
    if isinstance(a,list):return len(a)==len(b) and all(same(x,y) for x,y in zip(a,b))
    if isinstance(a,dict):return a.keys()==b.keys() and all(same(a[k],b[k]) for k in a)
    return a==b
   if same(case['expected'],result):passed+=1
   else:failures.append({'case':i,'status':'wrong_output'})
  except Exception as e:failures.append({'case':i,'status':'execution_error','type':type(e).__name__})
 print(json.dumps({'status':'correct' if not failures else 'coding_test_failure','correct':not failures,'passed':passed,'total':len(payload['cases']),'failures':failures[:100]}))
except Exception as e:print(json.dumps({'status':'execution_error','correct':False,'error_type':type(e).__name__}))
'''
def score_code(code,task_id,cases,image):
 failure,detail=policy(code)
 if failure:return {'status':failure,'correct':False,'detail':detail}
 try:
  subprocess.run(['docker','image','inspect',image],capture_output=True,check=True,timeout=10)
 except (OSError,subprocess.SubprocessError):return {'status':'execution_unavailable','correct':None,'detail':'Docker or pinned image unavailable; do not count as model failure.'}
 with tempfile.TemporaryDirectory(prefix='study-code-') as tmp:
  p=Path(tmp);p.chmod(0o755);(p/'payload.json').write_text(json.dumps({'code':code,'task_id':task_id,'cases':cases}));(p/'runner.py').write_text(RUNNER)
  for f in p.iterdir():f.chmod(0o644)
  name='study-v2-'+uuid.uuid4().hex
  cmd=['docker','run','--name',name,'--rm','--network','none','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges','--memory','256m','--memory-swap','256m','--cpus','1','--pids-limit','32','--user','65534:65534','--ulimit','cpu=10:10','--tmpfs','/tmp:rw,noexec,nosuid,size=16m','-v',tmp+':/task:ro',image,'python','-I','/task/runner.py']
  try:
   r=subprocess.run(cmd,capture_output=True,text=True,timeout=20)
   if r.returncode:return {'status':'container_failure','correct':False,'exit_code':r.returncode,'stderr':r.stderr[-2000:]}
   return json.loads(r.stdout)
  except subprocess.TimeoutExpired:return {'status':'execution_timeout','correct':False}
  except (ValueError,OSError) as e:return {'status':'harness_error','correct':None,'detail':str(e)}

  finally:
   subprocess.run(['docker','rm','-f',name],capture_output=True,timeout=10)
