# Study v1 candidate: 60 tasks

This is the actual study-suite design candidate, separate from the old pilot. It is not yet a frozen final measurement protocol.

20 reasoning tasks: two instances each of group discounts, mixture dilution, knapsack optimization, binary-string counting, linear equations, two-worker scheduling, probability without replacement, modular constraints, sequential percentages, and exhaustive constraint solutions.

20 data tasks: two instances each of filtered aggregation, relational joins, latest-record selection, median, weighted mean, interval union, inventory ledgers, distinct filtered users, ranked records with ties, and snapshot differences.

10 instruction tasks: operation precedence, case sensitivity, stable ordering, missing versus null values, boundary conditions, embedded untrusted instructions, exact JSON types/fields, unit conversion, ASCII sorting, and combined filtering/transformation rules.

10 coding tasks: interval merging, nested brackets, first unique character, longest equal run, rotation, all two-sum index pairs, run-length encoding, obstacle-grid path counting, unweighted shortest paths, and lexicographically smallest topological ordering.

## Files

- public/tasks.json: ONLY task prompts and task metadata. Send only one task prompt per request.
- private/answer_keys.json: reference answers, derivations, reference code and 44 hidden coding fixtures. NEVER provide this file to the tested model.
- private/validation.json: generator checks. Checks with hand-inspected instruction/fixture references are explicitly distinguished from algorithmic cross-checks in their method descriptions.
- manifest.json: source seed, category counts, task hashes and candidate status.
- REVIEW.html: readable task/answer review with answers collapsed. This includes private material; do not give it to the model.

Run `python3 scripts/validate_study.py` from the project root to verify hashes, authored coding references, known-correct answer scoring, and scorer edge cases. Reference code is ours; generated code MUST run only in an isolated container. Coding must be marked unscored until isolated execution is configured, never counted as passing.

## Scoring and review contract

Working is permitted. Final answer uses FINAL_JSON: followed by one JSON object, ending the response. No JSON grammar is imposed on generation: constraint compliance is a measured outcome. Math/data expected fields must match values and types; exact key set and no trailing text are separately checked. Per-field scores accompany all-or-nothing task success. Boolean true is not accepted as integer 1. Fractions must be in reduced form as requested.

Distinguish wrong answer, format failure, missing marker, invalid JSON, no final answer, truncation, timeout, inference error and coding execution error. Generated reasoning is archived with the question/final response but is not used as an implicit replacement for the required final answer. Review EVERY final response with the fixed rubric: substantive correctness, completeness, constraint compliance, contradictions, and failure cause. Preserve automatic/reviewer disagreements.

An organized per-attempt report must include full prompt, reference, final response, collapsed reasoning, objective scores, review, input/output token counts, timing, stop reason and runtime provenance. Character counts are not token counts.

## Before final measurement

1. Add independently generated coding edge cases and mutation checks beyond the 44 starter hidden fixtures; final code scoring needs a functioning isolated runner.
2. Pilot separate, comparable practice items to establish difficulty/output-budget distribution. The present difficulty labels are judgments, not measured calibration. Do not tune this final candidate based on quantization performance.
3. Choose a bounded reasoning/output policy. The 8K/6144 diagnostic still truncated a response and averaged 150 seconds across four problems. Sixty tasks with multiple trials may take hours. One hour is a planning target, not a reason to drop failures or give different formats different tasks.
4. Verify all model layers, KV/recurrent state reside on CUDA at the selected FIXED context for every quantization. Capture server startup logs, actual /props settings and fixed cache precision.
5. Reconcile runtime config with selected policy and freeze dataset/config/source hashes. Use identical task-seed pairs for every format; preregister repetitions and timeout/retry rules.
6. Collect separate repeated throughput workloads with fixed prompt lengths and generation lengths/context occupancy. Task-completion time is a separate metric.

## Integrity limitations

Fresh numeric instances reduce verbatim public-answer overlap but do not prove zero contamination. Instruction fixtures and algorithm patterns are familiar. This suite measures selected capabilities, not universal intelligence. Forty math/data instances cover only twenty families; avoid treating paired instances or repeated trials as fully independent evidence. Q8 is a quantized baseline. This suite has NOT yet been run against Q8.
