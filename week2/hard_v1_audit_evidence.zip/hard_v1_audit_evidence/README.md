# hard_v1 audit — evidence bundle

Independent checks behind the "hard_v1 Independent Audit" report. Verdict: **requires revision**.
No answer key was found wrong; see `findings.json` for the 19 findings (4 High, 7 Medium, 8 Low).

## Re-run

```
./run_all.sh /path/to/hard_v1 [/path/to/Benchmark-handoff]
```

* `hard_v1` is the extracted candidate package.
* The optional second argument is the extracted pinned archive
  (`https://raw.githubusercontent.com/m-oonlight/qwen3.5-9b_analysis/6aef6a78188e7a8c177992516435ed7bce0267e2/Benchmark-handoff.zip`,
  SHA-256 `12263a023222c3a745e98b36295bc251d2db1c7077980498750e509a3211b7bc`). Without it the package's
  `private/reference` copies are used; they are byte-identical to the pinned scripts.
* Python 3.12+ standard library only. About 3 minutes; outputs go to `results/`.
* Nothing here runs a benchmark model or reads model responses. The only programs executed are the package's
  own reference / slow / known-wrong programs and auditor-written code.

## What each script checks

| Script | Check | Key result |
|---|---|---|
| `indep_finite.py` | Re-solves all 220 finite keys by literal brute force, data parsed from the public prompt text | 220/220 match |
| `indep_coding.py` | Independent oracles (different algorithms) for all 1,480 hidden coding cases; validates every input against its published domain | 1,480/1,480 match; 0 invalid inputs |
| `sensitivity.py` | Alternative readings; each stated constraint dropped; 163 named wrong approaches applied | 6 keys change under unstated conventions; 29 inert constraints; 35 wrong approaches not rejected |
| `ties_siblings.py` | Optimal-solution multiplicity; byte identity of sibling prompts | tie-breaks matter in 2/20 optimisation items; 40/40 finite families identical apart from data |
| `mutants.py` | 88 plausible wrong programs vs the hidden suites | 88/88 killed; 17 by only 1-2 cases |
| `separation.py` | Counts, public/private leakage, calibration and legacy overlap | method sentence in 55/55 coding prompts; calibration has 0 recurrence items |
| `scorer_tests.py` | Proposed adapter vs pinned scorer on crafted responses | pinned scorer routes `algorithmic_python` to JSON (`invalid_json`) |
| `emu_suite.py` | Pinned AST policy + pinned in-container RUNNER (extracted from source), RLIMIT_CPU 10 s, 20 s wall | library used by the next two |
| `run_refs.py` | All 55 reference and 55 slow-correct programs through the emulated runner | refs 55/55 pass; 11/55 slow programs exceed the 10 s cap |
| `run_wrong.py` | The package's 10 known-wrong programs, executed | 10/10 pass policy and fail their declared witness |
| `budget_proxy.py` | Search-space and answer-size proxies per finite family (not difficulty measurements) | used for F06 judgment |

## Limits

* Emulation runs outside Docker (no 256 MiB cap, pids limit or read-only FS) on the auditor's CPU; timings vary by
  a few tenths of a second between runs and will differ on the pinned machine.
* The oracles are independent of the package's code but were written by one auditor.
* Difficulty / budget-fit statements are judgment until a reference-precision pilot runs.
