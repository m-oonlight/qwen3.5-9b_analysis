#!/usr/bin/env bash
# Re-run every auditor check. Usage:
#   ./run_all.sh /path/to/hard_v1 [/path/to/Benchmark-handoff]
# The second argument is the extracted pinned archive (optional). Without it, the package's
# private/reference copies are used; they were verified byte-identical to the pinned scripts.
set -euo pipefail
HV1="$(cd "$1" && pwd)"; PIN=""; if [ -n "${2:-}" ]; then PIN="$(cd "$2" && pwd)"; fi
HERE="$(cd "$(dirname "$0")" && pwd)"; S="$HERE/scripts"
if [ -n "$PIN" ]; then
  export PINNED_HARNESS="$PIN/scripts/study_code_harness_v2.py" PINNED_SCORER="$PIN/scripts/study_score_v2.py"
  LEGACY="$PIN/datasets/study_v2/public/tasks.json"
else
  export PINNED_HARNESS="$HV1/private/reference/study_code_harness_v2.py" PINNED_SCORER="$HV1/private/reference/study_score_v2.py"
  LEGACY=""
fi
mkdir -p "$HERE/results" && cd "$HERE/results"
echo "== 1. finite keys, independent brute force";        python3 -I "$S/indep_finite.py"  "$HV1"
echo "== 2. coding hidden outputs, independent oracles";  python3 -I "$S/indep_coding.py"  "$HV1"
echo "== 3. alternative readings / inert constraints / wrong approaches"; python3 -I "$S/sensitivity.py" "$HV1" > sensitivity.txt && grep "^==" sensitivity.txt
echo "== 4. tie multiplicity and sibling identity";      python3 -I "$S/ties_siblings.py" "$HV1" > ties_siblings.txt && tail -4 ties_siblings.txt
echo "== 5. mutation analysis of hidden suites";          python3 -I "$S/mutants.py"       "$HV1" > mutants.txt && head -2 mutants.txt
echo "== 6. separation, calibration overlap, legacy";     python3 -I "$S/separation.py"    "$HV1" $LEGACY
echo "== 7. scorer probes";                               python3 -I "$S/scorer_tests.py"  "$HV1"
echo "== 8. size proxies";                                python3 -I "$S/budget_proxy.py"  "$HV1" > budget_proxy.txt && echo "written budget_proxy.txt"
echo "== 9. known-wrong programs through emulated pinned runner"; python3 -I "$S/run_wrong.py" "$HV1" > wrong_runs.txt && echo "written wrong_runs.txt"
echo "== 10. reference + slow programs through emulated pinned runner (takes ~2-3 min)"; python3 -I "$S/run_refs.py" "$HV1" > ref_slow_runs.txt && echo "written ref_slow_runs.txt"
