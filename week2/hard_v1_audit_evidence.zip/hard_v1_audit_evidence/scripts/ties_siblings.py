import os as _os, sys as _sys
HERE = _os.path.dirname(_os.path.abspath(__file__)); _sys.path.insert(0, HERE)
import json, sys, itertools, importlib.util
from collections import defaultdict
spec = importlib.util.spec_from_file_location('indep', HERE + '/indep_finite.py'); ind = importlib.util.module_from_spec(spec); spec.loader.exec_module(ind)
root = sys.argv[1]
tasks = json.load(open(root + '/public/tasks.json')) + json.load(open(root + '/public/calibration.json'))
def D(t): return json.loads(t['prompt'].split('\nData (exact JSON): ', 1)[1].split('\n', 1)[0])
# --- number of optimal solutions (is the tie-break ever exercised?)
print('== optimal-solution multiplicity (tie-break exercised only if >1) ==')
for t in tasks:
    if t["category"] == "algorithmic_python": continue
    f = t["family"]; d = D(t)
    if f == 'vertex_cover':
        n = d['n']; sols = []
        for mask in range(1 << n):
            S = [i for i in range(n) if mask >> i & 1]
            if all(u in S or v in S for u, v in d['edges']): sols.append((sum(d['weights'][i] for i in S), S))
        b = min(s[0] for s in sols); print(t['id'], 'optimal covers:', sum(s[0] == b for s in sols))
    if f == 'assignment':
        C = d['cost']; n = len(C); sols = []
        for p in itertools.permutations(range(n)):
            if all(C[i][p[i]] is not None for i in range(n)): sols.append(sum(C[i][p[i]] for i in range(n)))
        print(t['id'], 'optimal assignments:', sols.count(min(sols)) if sols else 'infeasible')
    if f == 'interval_schedule':
        J = d['jobs']; n = len(J); vals = []
        for mask in range(1 << n):
            S = [i for i in range(n) if mask >> i & 1]
            if all(J[i][1] <= J[j][0] or J[j][1] <= J[i][0] for i, j in itertools.combinations(S, 2)): vals.append(sum(J[i][2] for i in S))
        print(t['id'], 'optimal schedules:', vals.count(max(vals)))
    if f == 'resource_path':
        out = {}
        for u, v, c, r in d['edges']: out.setdefault(u, []).append((v, c, r))
        paths = []
        def dfs(u, cost, res):
            if res > d['budget']: return
            if u == d['n'] - 1: paths.append(cost); return
            for v, c, r in out.get(u, []): dfs(v, cost + c, res + r)
        dfs(0, 0, 0)
        print(t['id'], 'optimal feasible paths:', paths.count(min(paths)) if paths else 'none')
# --- cosmetic siblings: prompt text with the data line removed
print('\n== sibling prompt identity (finite families) ==')
groups = defaultdict(set); members = defaultdict(int)
for t in tasks:
    if t['category'] == 'algorithmic_python': continue
    head, rest = t['prompt'].split('\nData (exact JSON): ', 1)
    tail = rest.split('\n', 1)[1]
    groups[t['family']].add(head + '||' + tail); members[t['family']] += 1
fams = sorted(groups)
print('finite families:', len(fams), '| families whose non-data prompt text is byte-identical across all members:', sum(len(groups[f]) == 1 for f in fams))
print('members per family incl. calibration:', sorted(set(members.values())))
# --- coding: prompt identity apart from the mode sentence
cg = defaultdict(list)
for t in tasks:
    if t['category'] == 'algorithmic_python': cg[t['family']].append(t['id'])
print('coding families:', len(cg))
