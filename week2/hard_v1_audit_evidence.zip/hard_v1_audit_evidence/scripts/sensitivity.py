"""Auditor analysis of finite tasks (independent of package oracles).
1. Alternative plausible readings: does the answer change?
2. Vacuous constraints: does dropping a stated constraint leave the answer unchanged?
3. Named wrong approaches from the package's own adversarial_checks: does the key reject them?
Run: python3 -I sensitivity.py <hard_v1 dir>
"""
import os as _os, sys as _sys
HERE = _os.path.dirname(_os.path.abspath(__file__)); _sys.path.insert(0, HERE)

import json, sys, itertools, math, copy
from fractions import Fraction
from collections import Counter
import importlib.util
spec = importlib.util.spec_from_file_location('indep', HERE + '/indep_finite.py')
ind = importlib.util.module_from_spec(spec); spec.loader.exec_module(ind)

root = sys.argv[1]
tasks = json.load(open(root + '/public/tasks.json')) + json.load(open(root + '/public/calibration.json'))
keys = {k['id']: k for k in json.load(open(root + '/private/answer_keys.json')) + json.load(open(root + '/private/calibration_keys.json'))}
fin = [t for t in tasks if t['category'] != 'algorithmic_python']

def D(t):
    return json.loads(t['prompt'].split('\nData (exact JSON): ', 1)[1].split('\n', 1)[0])

alt, vac, wrong = [], [], []

def note(lst, tid, label, ans, key):
    lst.append({'id': tid, 'variant': label, 'variant_answer': ans, 'key': key, 'same_as_key': json.dumps(ans) == json.dumps(key)})

for t in fin:
    f = t['family']; d = D(t); tid = t['id']; key = keys[tid]['expected']['answer']
    S = getattr(ind, f)
    # ---------- 1. alternative readings
    if f == 'digit_automaton':
        note(alt, tid, 'least-significant digit first', ind.digit_automaton(d, msb_first=False), key)
    if f == 'grid_paths':
        note(alt, tid, 'blocked read as [y,x]', ind.grid_paths(d, blocked_xy=False), key)
    if f == 'precedence_orders':
        inv = sorted([[p.index(i) for i in range(len(p))] for p in key])
        note(alt, tid, 'answer as position-of-label vectors', inv, key)
    if f == 'crt_window':
        d2 = copy.deepcopy(d)
        v = [x for x in range(d['lo'], d['hi'] + 1) if all(x % m in set(rs) for m, rs in d['rules']) and (x == 0 or math.gcd(abs(x), d['coprime']) == 1)]
        note(alt, tid, 'treat x=0 as coprime', v, key)
    # ---------- 2. vacuous constraints (drop one stated constraint)
    def drop(label, fn):
        note(vac, tid, label, fn(), key)
    if f == 'modular_roots':
        drop('drop residue filter', lambda: [x for x in range(d['m']) if (x*x + d['a']*x + d['b']) % d['m'] == 0])
    if f == 'divisor_filter':
        drop('drop "x mod k != r"', lambda: sum(x for x in range(1, d['n']+1) if d['n'] % x == 0 and math.gcd(x, d['n']//x) == d['g']))
    if f == 'digit_automaton':
        def da(adj=True, lead=True, dsum=True, mod=True):
            B, L = d['base'], d['length']; c = 0
            for g in itertools.product(range(B), repeat=L):
                if lead and g[0] == 0: continue
                if dsum and sum(g) != d['sum']: continue
                if adj and any(g[i] == g[i+1] for i in range(L-1)): continue
                v = 0
                for x in g: v = v*B + x
                if mod and v % d['m'] != d['r']: continue
                c += 1
            return c
        drop('drop unequal-adjacent', lambda: da(adj=False))
        drop('drop nonzero-first-digit', lambda: da(lead=False))
    if f == 'crt_window':
        drop('drop gcd filter', lambda: [x for x in range(d['lo'], d['hi']+1) if all(x % m in set(rs) for m, rs in d['rules'])])
    if f == 'independent_subset' and d['cyclic']:
        drop('ignore wraparound', lambda: ind.independent_subset({**d, 'cyclic': False}))
    if f == 'bounded_composition':
        drop('drop x[0]<=x[-1]', lambda: sum(1 for x in itertools.product(*[range(c+1) for c in d['caps']]) if sum(x) == d['total'] and sum((i+1)*x[i] for i in range(len(x))) % d['m'] == d['r']))
    if f == 'restricted_permutation':
        drop('drop forbidden pairs', lambda: ind.restricted_permutation({**d, 'forbidden': []}))
    if f == 'grid_paths':
        drop('drop blocked points', lambda: ind.grid_paths({**d, 'blocked': []}))
    if f == 'walk_probability':
        drop('drop [lo,hi] boundary', lambda: ind.walk_probability({**d, 'lo': -10**6, 'hi': 10**6}))
    if f == 'resource_path':
        drop('drop resource budget', lambda: ind.resource_path({**d, 'budget': 10**9}))
    if f == 'assignment':
        pass
    if f == 'relational_query':
        drop('drop minimum filter', lambda: ind.relational_query({**d, 'minimum': -10**9}))
        drop('drop having filter', lambda: ind.relational_query({**d, 'having': -10**9}))
    if f == 'truth_cycle':
        drop('drop minimum', lambda: ind.truth_cycle({**d, 'minimum': 0}))
    if f == 'matching_clues':
        drop('drop congruence', lambda: ind.matching_clues({**d, 'm': 1, 'r': 0}))
        drop('drop comparisons', lambda: ind.matching_clues({**d, 'comparisons': []}))
    if f == 'dfa_language':
        drop('drop DFA acceptance', lambda: ind.dfa_language({**d, 'accept': [0, 1, 2, 3]}))
    if f == 'boolean_models':
        drop('drop clauses', lambda: ind.boolean_models({**d, 'clauses': []}))
    if f == 'precedence_orders':
        drop('drop nonadjacent', lambda: ind.precedence_orders({**d, 'nonadjacent': []}))
    if f == 'set_membership':
        drop('drop singletons', lambda: [v for v in itertools.product(range(d['cap']+1), repeat=7)
                                          if sum(v) == d['union'] and all(sum(v[r-1] for r in range(1, 8) if r & mk == mk) == val for mk, val in d['intersections'])])
    if f == 'urn_conditional':
        drop('drop conditioning', lambda: ind.urn_conditional({**d, 'minimum': 0}))
    if f == 'permutation_probability':
        drop('drop conditioning', lambda: ind.permutation_probability({**d, 'excluded_first': -1}))
    # ---------- 3. the package's own named wrong approaches, computed
    def W(label, fn):
        note(wrong, tid, label, fn(), key)
    if f == 'modular_roots':
        pass
    if f == 'divisor_filter':
        W('gcd==1 instead of g', lambda: ind.divisor_filter({**d, 'g': 1}) if d['g'] != 1 else None)
    if f == 'digit_automaton':
        W('digit sum mod m instead of value', lambda: sum(1 for g in itertools.product(range(d['base']), repeat=d['length'])
            if g[0] and sum(g) == d['sum'] and all(g[i] != g[i+1] for i in range(len(g)-1)) and sum(g) % d['m'] == d['r']))
    if f == 'crt_window':
        W('open endpoints', lambda: [x for x in key if d['lo'] < x < d['hi']])
    if f == 'factorial_valuation':
        def legendre(p):
            s, q = 0, p
            while q <= d['n']: s += d['n']//q; q *= p
            return s
        W('sum of valuations / exps', lambda: sum(legendre(p)//e for p, e in zip(d['primes'], d['exponents'])))
        W('only first power (floor(n/p))', lambda: min((d['n']//p)//e for p, e in zip(d['primes'], d['exponents'])))
    if f == 'integer_system':
        W('dedupe permutations (sorted coords)', lambda: sorted({tuple(sorted(x)) for x in key}) and [list(x) for x in sorted({tuple(sorted(x)) for x in key})])
    if f == 'rational_roots':
        W('keep pole roots after clearing denominators', lambda: [x for x in range(-d['bound'], d['bound']+1)
            if d['coeff'][0]*(x-d['poles'][1]) + d['coeff'][1]*(x-d['poles'][0]) == d['coeff'][2]*(x-d['poles'][0])*(x-d['poles'][1])])
    if f == 'floor_equation':
        W('truncate toward zero', lambda: [x for x in range(d['lo'], d['hi']+1) if sum(int((a*x+b)/m) for a, b, m in d['terms']) == d['target']])
    if f == 'multiset_words':
        W('zero-based weights', lambda: (lambda words: sum(1 for w in words if all(w[j] != w[j+1] for j in range(len(w)-1)) and sum(j*w[j] for j in range(len(w))) % d['m'] == d['r']))(
            set(itertools.permutations([i for i, c in enumerate(d['counts']) for _ in range(c)]))))
    if f == 'grid_paths':
        W('count initial move as a turn', lambda: ind.grid_paths({**d, 'turns': d['turns'] - 1}))
    if f == 'urn_conditional':
        W('ignore conditioning (unconditional prob)', lambda: (lambda: None)())
    if f == 'walk_probability':
        pass
    if f == 'permutation_probability':
        def pp(cyclic=False, nfact=False):
            n = d['n']; fav = 0; tot = 0
            for p in itertools.permutations(range(n)):
                if not nfact and p[0] == d['excluded_first']: continue
                if p[0] == d['excluded_first'] and nfact:
                    tot += 1; continue
                tot += 1
                ds = sum(p[i] > p[i+1] for i in range(n-1)) + (int(p[n-1] > p[0]) if cyclic else 0)
                if sum(p[i] == i for i in range(n)) == d['fixed'] and ds == d['descents']: fav += 1
            fr = Fraction(fav, tot); return [fr.numerator, fr.denominator]
        W('n! denominator', lambda: pp(nfact=True))
        W('cyclic descents', lambda: pp(cyclic=True))
    if f == 'subset_probability':
        def sp(unordered=False):
            subs = list(itertools.combinations(range(d['n']), d['k'])); fav = tot = 0
            for i, A in enumerate(subs):
                for j, B in enumerate(subs):
                    if unordered and j < i: continue
                    tot += 1
                    if len(set(A) & set(B)) == d['intersection'] and sum(A) + sum(B) >= d['threshold']: fav += 1
            fr = Fraction(fav, tot); return [fr.numerator, fr.denominator]
        W('unordered pairs', lambda: sp(unordered=True))
    if f == 'vertex_cover':
        def vc_mask():
            n = d['n']; best = None
            for mask in range(1 << n):
                S = [i for i in range(n) if mask >> i & 1]
                if all(u in S or v in S for u, v in d['edges']):
                    c = sum(d['weights'][i] for i in S)
                    if best is None or c < best[0]: best = (c, S)
            return {'cost': best[0], 'vertices': best[1]}
        W('tie-break by first mask found', vc_mask)
    if f == 'coupled_recurrence':
        def cr(seq=False, t1=False):
            a, b = d['initial']; c = d['coeff']; m = d['m']
            for t in range(d['n']):
                tt = t + 1 if t1 else t
                a2 = (c[0]*a + c[1]*b + tt) % m
                b = (c[2]*(a2 if seq else a) + c[3]*b + tt*tt) % m
                a = a2
            return [a, b]
        W('update b with new a', lambda: cr(seq=True))
        W('start t at 1', lambda: cr(t1=True))
    if f == 'substitution':
        def sub_nonoverlap():
            s = d['start']
            for _ in range(d['n']): s = ''.join(d['rules'][int(ch)] for ch in s)
            return s.count(d['pattern'])
        W('non-overlapping count (str.count)', sub_nonoverlap)
    if f == 'functional_graph':
        def fg_off():
            r = ind.functional_graph(d); dd = dict(d); dd['k'] = d['k'] - 1
            return {**r, 'value': ind.functional_graph(dd)['value']}
        W('x_(k-1) off-by-one', fg_off)
    if f == 'periodic_matrix':
        def pm(rev=False, row=False):
            v = list(d['initial']); m = d['m']; Ms = d['matrices']
            for t in range(d['n']):
                M = Ms[(len(Ms) - 1 - t % len(Ms)) if rev else t % len(Ms)]
                if row: M = [list(c) for c in zip(*M)]
                v = [sum(M[i][j]*v[j] for j in range(len(v))) % m for i in range(len(v))]
            return v
        W('reverse matrix order', lambda: pm(rev=True))
        W('row vectors (transpose)', lambda: pm(row=True))
    if f == 'boolean_models':
        W('zero-based literals (shift)', lambda: None)
    if f == 'precedence_orders':
        def po_label():
            out = []
            for p in itertools.permutations(range(d['n'])):
                pos = {lab: i for i, lab in enumerate(p)}
                if all(pos[a] < pos[b] for a, b in d['before']) and all(abs(a - b) != 1 or True for a, b in d['nonadjacent']):
                    # adjacency applied to label values: forbid consecutive positions only if labels differ by 1 (nonsense) -> drop
                    out.append(list(p))
            return out
        W('before = immediately before', lambda: [list(p) for p in itertools.permutations(range(d['n']))
            if all(p.index(b) == p.index(a) + 1 for a, b in d['before']) and all(abs(p.index(a)-p.index(b)) != 1 for a, b in d['nonadjacent'])])
    if f == 'relational_query':
        W('deduplicate rows', lambda: ind.relational_query({**d, 'a': [list(x) for x in sorted({tuple(r) for r in d['a']})], 'b': [list(x) for x in sorted({tuple(r) for r in d['b']})]}))
    if f == 'truth_cycle':
        def tc_bicond():
            n = d['n']; out = []
            for x in itertools.product([0, 1], repeat=n):
                ok = True
                for i, (a, b, op) in enumerate(d['statements']):
                    val = (x[a] + x[b]) == 1 if op == 'xor' else x[a] == x[b]
                    if x[i] != int(val): ok = False; break
                if ok and sum(x) >= d['minimum']: out.append(list(x))
            return out
        W('implication as biconditional', tc_bicond)
    if f == 'transaction_log':
        def tl_changed_only():
            st = list(d['initial']); hist = []
            for op in d['ops']:
                if op[0] == 'undo':
                    for _ in range(op[1]):
                        if hist: st = hist.pop()
                    continue
                before = list(st)
                if op[0] == 'add': st[op[1]] += op[2]
                elif op[0] == 'swap': st[op[1]], st[op[2]] = st[op[2]], st[op[1]]
                else:
                    if st[op[1]] < st[op[2]]: st[op[2]] -= op[3]; st[op[1]] += op[3]
                if st != before: hist.append(before)
            return st
        W('undo only state-changing commands', tl_changed_only)
        W('answer = initial list', lambda: list(d['initial']))
    if f == 'set_membership':
        W('inclusive intersection read as exact region', lambda: [list(v) for v in itertools.product(range(d['cap']+1), repeat=7)
            if sum(v) == d['union'] and all(v[mk-1] == val for mk, val in d['intersections']) and v[0]+v[1]+v[3] == d['singletons']])
    if f == 'cellular_ring':
        def cr2(rev=False, openb=False):
            s = list(d['initial']); L = len(s)
            for _ in range(d['n']):
                def g(i):
                    if openb and (i < 0 or i >= L): return 0
                    return s[i % L]
                s = [d['rule'][(4*g(i+1) + 2*s[i] + g(i-1)) if rev else (4*g(i-1) + 2*s[i] + g(i+1))] for i in range(L)]
            return s
        W('reverse left/right encoding', lambda: cr2(rev=True))
        W('open boundary zeros', lambda: cr2(openb=True))
    if f == 'dfa_language':
        W('at most `ones` ones', lambda: sorted(w for w in (''.join(b) for b in itertools.product('01', repeat=d['length']))
            if w.count('1') <= d['ones'] and '11' not in w and (lambda q: q in d['accept'])(
                __import__('functools').reduce(lambda q, ch: d['transition'][q][int(ch)], w, d['start']))))
    if f == 'poset_ideals':
        def filt():
            n = d['n']; le = [[i == j for j in range(n)] for i in range(n)]
            for a, b in d['relations']: le[a][b] = True
            for k in range(n):
                for i in range(n):
                    for j in range(n):
                        if le[i][k] and le[k][j]: le[i][j] = True
            return [list(S) for S in itertools.combinations(range(n), d['k']) if all(b in S for a in S for b in range(n) if le[a][b])]
        W('filters instead of ideals', filt)
        W('ignore transitivity (generating relations only)', lambda: None)

# Remove placeholder rows (fn returned None)
wrong = [w for w in wrong if w['variant_answer'] is not None]
json.dump({'alternative_readings': alt, 'vacuous_constraints': vac, 'wrong_approaches': wrong}, open('sensitivity_results.json', 'w'), indent=1)

def summarize(name, rows):
    print('==', name, '==', len(rows), 'checks;', sum(r['same_as_key'] for r in rows), 'give the SAME answer as the key')
    for r in rows:
        if r['same_as_key']:
            print('   SAME:', r['id'], '|', r['variant'])
summarize('alternative readings', alt)
print()
summarize('vacuous constraints (dropping the constraint leaves the key unchanged)', vac)
print()
summarize('named wrong approaches (not rejected by the key)', wrong)
