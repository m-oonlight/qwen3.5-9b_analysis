"""Independent brute-force solvers for hard_v1 finite tasks.

Written by the auditor from the PUBLIC PROMPT TEXT ONLY (not from private/oracles/finite.py).
Every solver enumerates the full finite search space literally, as the prompt words it,
so it shares no recurrence/DP/shortcut with the package's own oracles.
Run:  python3 -I indep_finite.py <path-to-hard_v1>
"""
import json, sys, itertools, math
from fractions import Fraction
from collections import Counter

# ---------------------------------------------------------------- arithmetic / number theory
def modular_roots(d):
    m, a, b, k, res = d['m'], d['a'], d['b'], d['k'], set(d['residues'])
    return [x for x in range(m) if (x * x + a * x + b) % m == 0 and x % k in res]

def divisor_filter(d):
    n, g, k, r = d['n'], d['g'], d['k'], d['r']
    return sum(x for x in range(1, n + 1) if n % x == 0 and math.gcd(x, n // x) == g and x % k != r)

def digit_automaton(d, msb_first=True):
    B, L, S, m, r = d['base'], d['length'], d['sum'], d['m'], d['r']
    cnt = 0
    for digs in itertools.product(range(B), repeat=L):
        if digs[0] == 0 or sum(digs) != S:
            continue
        if any(digs[i] == digs[i + 1] for i in range(L - 1)):
            continue
        seq = digs if msb_first else digs[::-1]
        val = 0
        for t in seq:
            val = val * B + t
        if val % m == r:
            cnt += 1
    return cnt

def crt_window(d):
    out = []
    for x in range(d['lo'], d['hi'] + 1):
        if math.gcd(abs(x), d['coprime']) != 1:
            continue
        if all(x % m in set(rs) for m, rs in d['rules']):
            out.append(x)
    return out

def factorial_valuation(d):
    f = math.factorial(d['n'])
    B = 1
    for p, e in zip(d['primes'], d['exponents']):
        B *= p ** e
    t = 0
    while f % B == 0:
        f //= B
        t += 1
    return t

# ---------------------------------------------------------------- algebra
def integer_system(d):
    R = range(-d['bound'], d['bound'] + 1)
    out = []
    for x in R:
        for y in R:
            for z in R:
                if x + y + z == d['s'] and x * y + y * z + z * x == d['p'] and \
                   x * x + y * y + z * z + d['a'] * x + d['b'] * y == d['t']:
                    out.append([x, y, z])
    return sorted(out)

def rational_roots(d):
    c0, c1, c2 = d['coeff']
    p0, p1 = d['poles']
    out = []
    for x in range(-d['bound'], d['bound'] + 1):
        if x == p0 or x == p1:
            continue
        if Fraction(c0, x - p0) + Fraction(c1, x - p1) == c2:
            out.append(x)
    return out

def finite_linear(d):
    p, A, b = d['p'], d['a'], d['b']
    n = len(A[0])
    out = []
    for x in itertools.product(range(p), repeat=n):
        if all(sum(A[i][j] * x[j] for j in range(n)) % p == b[i] % p for i in range(len(A))):
            out.append(list(x))
    return sorted(out)

def interpolation(d):
    pts = d['points']; q = d['query']
    # Solve Vandermonde system exactly with Fractions (different basis from Lagrange/Newton)
    n = len(pts)
    M = [[Fraction(x) ** j for j in range(n)] + [Fraction(y)] for x, y in pts]
    for c in range(n):
        piv = next(r for r in range(c, n) if M[r][c] != 0)
        M[c], M[piv] = M[piv], M[c]
        for r in range(n):
            if r != c and M[r][c] != 0:
                f = M[r][c] / M[c][c]
                M[r] = [a - f * b for a, b in zip(M[r], M[c])]
    coef = [M[i][n] / M[i][i] for i in range(n)]
    v = sum(c * Fraction(q) ** j for j, c in enumerate(coef))
    return [v.numerator, v.denominator]

def floor_equation(d):
    out = []
    for x in range(d['lo'], d['hi'] + 1):
        s = sum(math.floor(Fraction(a * x + b, m)) for a, b, m in d['terms'])
        if s == d['target']:
            out.append(x)
    return out

# ---------------------------------------------------------------- combinatorics
def multiset_words(d):
    counts, m, r = d['counts'], d['m'], d['r']
    letters = [i for i, c in enumerate(counts) for _ in range(c)]
    words = set(itertools.permutations(letters))
    cnt = 0
    for w in words:
        if any(w[j] == w[j + 1] for j in range(len(w) - 1)):
            continue
        if sum((j + 1) * w[j] for j in range(len(w))) % m == r:
            cnt += 1
    return cnt

def independent_subset(d):
    w, k, T, cyc = d['weights'], d['k'], d['target'], d['cyclic']
    n = len(w); cnt = 0
    for S in itertools.combinations(range(n), k):
        bad = False
        for a, b in itertools.combinations(S, 2):
            if abs(a - b) == 1 or (cyc and {a, b} == {0, n - 1}):
                bad = True; break
        if not bad and sum(w[i] for i in S) == T:
            cnt += 1
    return cnt

def bounded_composition(d):
    caps, total, m, r = d['caps'], d['total'], d['m'], d['r']
    cnt = 0
    for x in itertools.product(*[range(c + 1) for c in caps]):
        if sum(x) == total and sum((i + 1) * x[i] for i in range(len(x))) % m == r and x[0] <= x[-1]:
            cnt += 1
    return cnt

def cycle_lengths(p):
    n = len(p); seen = [False] * n; out = []
    for i in range(n):
        if not seen[i]:
            L = 0; j = i
            while not seen[j]:
                seen[j] = True; j = p[j]; L += 1
            out.append(L)
    return out

def restricted_permutation(d):
    n = d['n']; cnt = 0
    bad = set(d['bad_lengths'])
    for p in itertools.permutations(range(n)):
        cl = cycle_lengths(p)
        if len(cl) != d['cycles'] or any(L in bad for L in cl):
            continue
        if any(p[a] == b for a, b in d['forbidden']):
            continue
        cnt += 1
    return cnt

def grid_paths(d, blocked_xy=True):
    w, h, T = d['w'], d['h'], d['turns']
    blocked = {tuple(b) if blocked_xy else (b[1], b[0]) for b in d['blocked']}
    cnt = 0
    for norths in itertools.combinations(range(w + h), h):
        ns = set(norths)
        moves = ['N' if i in ns else 'E' for i in range(w + h)]
        x = y = 0
        ok = (0, 0) not in blocked
        for mv in moves:
            if mv == 'E': x += 1
            else: y += 1
            if (x, y) in blocked: ok = False
        if not ok:
            continue
        turns = sum(moves[i] != moves[i + 1] for i in range(len(moves) - 1))
        if turns == T:
            cnt += 1
    return cnt

# ---------------------------------------------------------------- probability
def urn_conditional(d):
    balls = [c for c, cnt in enumerate(d['counts']) for _ in range(cnt)]
    fav = cond = 0
    for S in itertools.combinations(range(len(balls)), d['draw']):
        cols = Counter(balls[i] for i in S)
        if cols[0] < d['minimum']:
            continue
        cond += 1
        if len(cols) == d['distinct'] and cols[1] % 2 == d['parity']:
            fav += 1
    f = Fraction(fav, cond)
    return [f.numerator, f.denominator]

def walk_probability(d):
    good = 0; tot = 0
    for seq in itertools.product(d['steps'], repeat=d['n']):
        tot += 1
        pos = d['start']
        ok = d['lo'] <= pos <= d['hi']
        for s in seq:
            pos += s
            if not (d['lo'] <= pos <= d['hi']):
                ok = False
        if ok and pos == d['end']:
            good += 1
    f = Fraction(good, tot)
    return [f.numerator, f.denominator]

def permutation_probability(d):
    n = d['n']; fav = tot = 0
    for p in itertools.permutations(range(n)):
        if p[0] == d['excluded_first']:
            continue
        tot += 1
        fx = sum(p[i] == i for i in range(n))
        ds = sum(p[i] > p[i + 1] for i in range(n - 1))
        if fx == d['fixed'] and ds == d['descents']:
            fav += 1
    f = Fraction(fav, tot)
    return [f.numerator, f.denominator]

def subset_probability(d):
    n, k = d['n'], d['k']
    subs = list(itertools.combinations(range(n), k))
    fav = 0
    for A in subs:
        for B in subs:
            if len(set(A) & set(B)) == d['intersection'] and sum(A) + sum(B) >= d['threshold']:
                fav += 1
    f = Fraction(fav, len(subs) ** 2)
    return [f.numerator, f.denominator]

def network_reliability(d):
    n, E = d['n'], d['edges']
    tot = Fraction(0)
    for state in itertools.product([0, 1], repeat=len(E)):
        pr = Fraction(1)
        adj = {i: set() for i in range(n)}
        for s, (u, v, a, b) in zip(state, E):
            p = Fraction(a, b)
            pr *= p if s else (1 - p)
            if s:
                adj[u].add(v); adj[v].add(u)
        seen = {0}; stack = [0]
        while stack:
            x = stack.pop()
            for y in adj[x]:
                if y not in seen:
                    seen.add(y); stack.append(y)
        if n - 1 in seen:
            tot += pr
    return [tot.numerator, tot.denominator]

# ---------------------------------------------------------------- optimization / graphs
def vertex_cover(d):
    n, w, E = d['n'], d['weights'], d['edges']
    best = None
    for mask in range(1 << n):
        S = [i for i in range(n) if mask >> i & 1]
        ss = set(S)
        if all(u in ss or v in ss for u, v in E):
            c = sum(w[i] for i in S)
            cand = (c, S)
            if best is None or cand < best:
                best = cand
    return {'cost': best[0], 'vertices': best[1]}

def spanning_tree(d):
    n, E = d['n'], d['edges']
    best = None; cnt = 0
    for T in itertools.combinations(range(len(E)), n - 1):
        # connectivity check by repeated relaxation (no union-find)
        reach = {0}
        changed = True
        while changed:
            changed = False
            for i in T:
                u, v, _ = E[i]
                if (u in reach) != (v in reach):
                    reach |= {u, v}; changed = True
        if len(reach) != n:
            continue
        c = sum(E[i][2] for i in T)
        if best is None or c < best:
            best, cnt = c, 1
        elif c == best:
            cnt += 1
    if best is None:
        return {'cost': None, 'count': 0}
    return {'cost': best, 'count': cnt}

def resource_path(d):
    n, E, B = d['n'], d['edges'], d['budget']
    out_e = {}
    for u, v, c, r in E:
        out_e.setdefault(u, []).append((v, c, r))
    paths = []
    def dfs(u, path, cost, res):
        if res > B:
            return
        if u == n - 1:
            paths.append((cost, path[:])); return
        for v, c, r in out_e.get(u, []):
            path.append(v); dfs(v, path, cost + c, res + r); path.pop()
    dfs(0, [0], 0, 0)
    if not paths:
        return {'cost': None, 'path': []}
    best = min(paths)
    return {'cost': best[0], 'path': best[1]}

def assignment(d):
    C = d['cost']; n = len(C)
    best = None
    for p in itertools.permutations(range(n)):
        if any(C[i][p[i]] is None for i in range(n)):
            continue
        c = sum(C[i][p[i]] for i in range(n))
        cand = (c, list(p))
        if best is None or cand < best:
            best = cand
    if best is None:
        return {'cost': None, 'assignment': []}
    return {'cost': best[0], 'assignment': best[1]}

def interval_schedule(d):
    J = d['jobs']; n = len(J)
    best = None
    for mask in range(1 << n):
        S = [i for i in range(n) if mask >> i & 1]
        ok = all(J[i][1] <= J[j][0] or J[j][1] <= J[i][0] for i, j in itertools.combinations(S, 2))
        if not ok:
            continue
        v = sum(J[i][2] for i in S)
        cand = (-v, S)
        if best is None or cand < best:
            best = cand
    return {'value': -best[0], 'jobs': best[1]}

# ---------------------------------------------------------------- sequences / recurrences
def coupled_recurrence(d):
    a, b = d['initial']; c = d['coeff']; m = d['m']
    for t in range(d['n']):
        a, b = (c[0] * a + c[1] * b + t) % m, (c[2] * a + c[3] * b + t * t) % m
    return [a % m, b % m]

def substitution(d):
    s = d['start']
    for _ in range(d['n']):
        s = ''.join(d['rules'][int(ch)] for ch in s)
    p = d['pattern']
    return sum(1 for i in range(len(s) - len(p) + 1) if s[i:i + len(p)] == p)

def functional_graph(d):
    m = d['m']
    f = lambda x: (d['a'] * x * x + d['b'] * x + d['c']) % m
    seq = [d['start']]
    first = {d['start']: 0}
    while True:
        nx = f(seq[-1])
        if nx in first:
            mu = first[nx]; lam = len(seq) - mu
            break
        first[nx] = len(seq); seq.append(nx)
    k = d['k']
    val = seq[k] if k < len(seq) else seq[mu + (k - mu) % lam]
    return {'preperiod': mu, 'period': lam, 'value': val}

def subtraction_game(d):
    g = [0]
    for t in range(1, d['n'] + 1):
        reach = {g[t - v] for v in d['moves'] if v <= t}
        x = 0
        while x in reach:
            x += 1
        g.append(x)
    return [t for t in range(d['lo'], d['n'] + 1) if g[t] == d['target']]

def periodic_matrix(d):
    v = list(d['initial']); m = d['m']; Ms = d['matrices']
    for t in range(d['n']):
        M = Ms[t % len(Ms)]
        v = [sum(M[i][j] * v[j] for j in range(len(v))) % m for i in range(len(v))]
    return [x % m for x in v]

# ---------------------------------------------------------------- logic / data / constraints
def boolean_models(d):
    n = d['n']; out = []
    for x in itertools.product([0, 1], repeat=n):
        if sum(x) != d['weight']:
            continue
        if all(any((x[v - 1] == 1) if v > 0 else (x[-v - 1] == 0) for v in cl) for cl in d['clauses']):
            out.append(list(x))
    return out

def precedence_orders(d):
    out = []
    for p in itertools.permutations(range(d['n'])):
        pos = {lab: i for i, lab in enumerate(p)}
        if all(pos[a] < pos[b] for a, b in d['before']) and all(abs(pos[a] - pos[b]) != 1 for a, b in d['nonadjacent']):
            out.append(list(p))
    return out

def relational_query(d):
    groups = {}
    for ka, g, val in d['a']:
        for kb, mult in d['b']:
            if ka == kb and val >= d['minimum']:
                groups[g] = groups.get(g, 0) + val * mult
    return sorted([[g, t] for g, t in groups.items() if t >= d['having']])

def truth_cycle(d):
    n = d['n']; out = []
    for x in itertools.product([0, 1], repeat=n):
        ok = True
        for i, (a, b, op) in enumerate(d['statements']):
            if op == 'xor':
                val = (x[a] + x[b]) == 1
            elif op == 'implies':
                val = (not x[a]) or bool(x[b])
            else:
                raise ValueError(op)
            if x[i] != int(val):
                ok = False; break
        if ok and sum(x) >= d['minimum']:
            out.append(list(x))
    return out

def transaction_log(d):
    # replay-from-log implementation: keep the list of active commands; recompute state by replay
    active = []
    def replay(cmds):
        st = list(d['initial'])
        for op in cmds:
            if op[0] == 'add':
                st[op[1]] += op[2]
            elif op[0] == 'swap':
                st[op[1]], st[op[2]] = st[op[2]], st[op[1]]
            elif op[0] == 'conditional':
                i, j, t = op[1], op[2], op[3]
                if st[i] < st[j]:
                    st[j] -= t; st[i] += t
        return st
    for op in d['ops']:
        if op[0] == 'undo':
            k = op[1]
            if k > 0:
                active = active[:-k] if k < len(active) else []
        else:
            active.append(op)
    return replay(active)

def matching_clues(d):
    n = d['n']; out = []
    for p in itertools.permutations(range(n)):
        if not all(p[a] in vals for a, vals in d['allowed']):
            continue
        if not all((p[a] < p[b]) == t for a, b, t in d['comparisons']):
            continue
        if sum((i + 1) * p[i] for i in range(n)) % d['m'] != d['r']:
            continue
        out.append(list(p))
    return out

def set_membership(d):
    out = []
    for v in itertools.product(range(d['cap'] + 1), repeat=7):
        cell = {mask: v[mask - 1] for mask in range(1, 8)}
        if sum(v) != d['union']:
            continue
        ok = True
        for mask, val in d['intersections']:
            # inclusive intersection of the sets named in mask = all regions containing ALL those bits
            if sum(cell[r] for r in range(1, 8) if r & mask == mask) != val:
                ok = False; break
        if not ok:
            continue
        if cell[1] + cell[2] + cell[4] != d['singletons']:
            continue
        out.append(list(v))
    return out

def cellular_ring(d):
    s = list(d['initial']); L = len(s)
    for _ in range(d['n']):
        s = [d['rule'][4 * s[(i - 1) % L] + 2 * s[i] + s[(i + 1) % L]] for i in range(L)]
    return s

def dfa_language(d):
    out = []
    for bits in itertools.product('01', repeat=d['length']):
        w = ''.join(bits)
        if w.count('1') != d['ones'] or '11' in w:
            continue
        q = d['start']
        for ch in w:
            q = d['transition'][q][int(ch)]
        if q in d['accept']:
            out.append(w)
    return sorted(out)

def poset_ideals(d):
    n = d['n']
    le = [[i == j for j in range(n)] for i in range(n)]
    for a, b in d['relations']:
        le[a][b] = True
    for k in range(n):          # Warshall closure
        for i in range(n):
            for j in range(n):
                if le[i][k] and le[k][j]:
                    le[i][j] = True
    out = []
    for S in itertools.combinations(range(n), d['k']):
        ss = set(S)
        if all(a in ss for b in S for a in range(n) if le[a][b]):
            out.append(list(S))
    return out

SOLVERS = {k: v for k, v in globals().items() if callable(v) and not k.startswith('_')}

def main(root):
    tasks = json.load(open(root + '/public/tasks.json')) + json.load(open(root + '/public/calibration.json'))
    keys = json.load(open(root + '/private/answer_keys.json')) + json.load(open(root + '/private/calibration_keys.json'))
    km = {k['id']: k for k in keys}
    results = []
    for t in tasks:
        if t['category'] == 'algorithmic_python':
            continue
        # Parse the DATA straight out of the public prompt (not from the private parameters)
        data = json.loads(t['prompt'].split('\nData (exact JSON): ', 1)[1].split('\n', 1)[0])
        priv = km[t['id']]['parameters']
        if data != priv:
            results.append((t['id'], 'PROMPT_DATA_NE_PRIVATE_PARAMETERS', None, None))
        mine = SOLVERS[t['family']](data)
        theirs = km[t['id']]['expected']['answer']
        same = json.dumps(mine) == json.dumps(theirs)
        results.append((t['id'], 'MATCH' if same else 'MISMATCH', mine, theirs))
    mism = [r for r in results if r[1] != 'MATCH']
    print('finite tasks checked:', sum(1 for r in results if r[1] in ('MATCH', 'MISMATCH')))
    print('matches:', sum(1 for r in results if r[1] == 'MATCH'))
    for r in mism:
        print(r)
    json.dump([{'id': r[0], 'status': r[1], 'independent': r[2], 'key': r[3]} for r in results],
              open('indep_finite_results.json', 'w'), indent=1)

if __name__ == '__main__':
    main(sys.argv[1])
