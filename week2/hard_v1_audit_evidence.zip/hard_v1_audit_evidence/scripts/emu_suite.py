"""Emulate the PINNED harness (study_code_harness_v2.py) outside Docker, for package-authored and
auditor-authored programs only (never model responses).

- policy(): the pinned AST policy, extracted from the pinned source file by AST (not imported/executed)
- RUNNER : the pinned in-container runner string, extracted the same way, run with `python3 -I`
           under RLIMIT_CPU=10 s (the container ulimit) and a 20 s wall timeout (the host timeout).
Docker's 256 MiB memory cap, pids limit and read-only FS are NOT reproduced; peak RSS is reported.

Usage (library): run_suite(code, task_id, cases) -> dict(status, cpu_s, wall_s, maxrss_mb, ...)
"""
import ast, json, os, subprocess, sys, tempfile, time, resource
from pathlib import Path

PINNED = Path(os.environ['PINNED_HARNESS'])  # path to study_code_harness_v2.py (pinned archive or the byte-identical package copy)
_src = PINNED.read_text()
_tree = ast.parse(_src)
RUNNER = next(n.value.value for n in _tree.body if isinstance(n, ast.Assign) and getattr(n.targets[0], 'id', '') == 'RUNNER')
_policy_src = ast.get_source_segment(_src, next(n for n in _tree.body if isinstance(n, ast.FunctionDef) and n.name == 'policy'))
_ns = {'ast': ast}
exec(compile(_policy_src, 'pinned_policy', 'exec'), _ns)   # only the policy() function body, which is pure AST inspection
policy = _ns['policy']

def _limits():
    resource.setrlimit(resource.RLIMIT_CPU, (10, 10))

def run_suite(code, task_id, cases, wall=20):
    err, detail = policy(code)
    if err:
        return {'status': err, 'detail': detail, 'correct': False, 'cpu_s': 0.0, 'wall_s': 0.0}
    with tempfile.TemporaryDirectory(prefix='emu-') as tmp:
        p = Path(tmp)
        (p / 'payload.json').write_text(json.dumps({'code': code, 'task_id': task_id, 'cases': cases}))
        (p / 'runner.py').write_text(RUNNER.replace('/task/payload.json', str(p / 'payload.json')))
        # wrapper: runs the runner as ITS child and reports that child's own CPU time and peak RSS
        (p / 'wrap.py').write_text('import resource,subprocess,sys,json\n'
            'def lim():\n resource.setrlimit(resource.RLIMIT_CPU,(10,10))\n'
            'r=subprocess.run([sys.executable,"-I",sys.argv[1]],capture_output=True,text=True,preexec_fn=lim)\n'
            'u=resource.getrusage(resource.RUSAGE_CHILDREN)\n'
            'sys.stdout.write(r.stdout)\n'
            'sys.stderr.write(json.dumps({"rc":r.returncode,"cpu":u.ru_utime+u.ru_stime,"rss":u.ru_maxrss,"err":r.stderr[-300:]}))\n')
        t0 = time.time()
        try:
            r = subprocess.run([sys.executable, '-I', str(p / 'wrap.py'), str(p / 'runner.py')], capture_output=True, text=True,
                               timeout=wall, cwd=tmp)
            wall_s = time.time() - t0
        except subprocess.TimeoutExpired:
            return {'status': 'execution_timeout', 'correct': False, 'cpu_s': None, 'wall_s': wall}
        meta = json.loads(r.stderr)
        cpu = meta['cpu']
        class _R: pass
        after = _R(); after.ru_maxrss = meta['rss']
        r.returncode = meta['rc']; r.stderr = meta['err']
        if r.returncode:
            return {'status': 'container_failure(cpu-limit or crash)', 'correct': False, 'exit_code': r.returncode,
                    'cpu_s': round(cpu, 2), 'wall_s': round(wall_s, 2), 'stderr': r.stderr[-300:]}
        out = json.loads(r.stdout)
        out.update(cpu_s=round(cpu, 2), wall_s=round(wall_s, 2), maxrss_mb=round(after.ru_maxrss / 1024, 1))
        return out
