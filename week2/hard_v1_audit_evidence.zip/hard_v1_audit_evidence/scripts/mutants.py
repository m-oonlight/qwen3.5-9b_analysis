"""Auditor mutation analysis: plausible WRONG programs per coding task, run against the stored hidden cases.
A mutant 'survives' if it reproduces every expected output, i.e. the hidden suite cannot tell it from a correct
solution. All mutants are auditor-written; no model code is involved.
Run: python3 -I mutants.py <hard_v1 dir>
"""
import os as _os, sys as _sys
HERE = _os.path.dirname(_os.path.abspath(__file__)); _sys.path.insert(0, HERE)

import json, sys, itertools, re, importlib.util
from collections import Counter, deque
spec = importlib.util.spec_from_file_location('ic', HERE + '/indep_coding.py'); ic = importlib.util.module_from_spec(spec); spec.loader.exec_module(ic)

M = {}   # task id -> list of (name, fn(data))
def mut(tid, name):
    def deco(fn):
        M.setdefault(tid, []).append((name, fn)); return fn
    return deco

# ------------------------------------------------ array_ranges
def window_pos(a, k, mode):
    # positive-only sliding window idioms
    n = len(a)
    if mode == 0:
        l = s = best = 0
        for r, x in enumerate(a):
            s += x
            while l <= r and s > k: s -= a[l]; l += 1
            best = max(best, r - l + 1)
        return best
    if mode == 1:
        l = s = cnt = 0
        for r, x in enumerate(a):
            s += x
            while l <= r and s > k: s -= a[l]; l += 1
            if s == k and l <= r: cnt += 1
        return cnt
    if mode == 2:
        l = s = 0; best = None
        for r, x in enumerate(a):
            s += x
            while l <= r and s >= k:
                best = r - l + 1 if best is None else min(best, r - l + 1); s -= a[l]; l += 1
        return -1 if best is None else best
mut('HV1-ARRAY_RANGES-01', 'positive-only sliding window')(lambda d: window_pos(d['a'], d['k'], 0))
mut('HV1-ARRAY_RANGES-01', 'strict sum<k')(lambda d: ic.array_ranges({**d, 'k': d['k'] - 1}, 0))
mut('HV1-ARRAY_RANGES-01', 'return -1 when none')(lambda d: ic.array_ranges(d, 0) or -1)
mut('HV1-ARRAY_RANGES-02', 'positive-only sliding window')(lambda d: window_pos(d['a'], d['k'], 1))
def count_noinit(d):
    cnt = Counter(); s = out = 0
    for x in d['a']:
        s += x; out += cnt[s - d['k']]; cnt[s] += 1
    return out
mut('HV1-ARRAY_RANGES-02', 'prefix map missing empty prefix')(count_noinit)
mut('HV1-ARRAY_RANGES-03', 'positive-only sliding window')(lambda d: window_pos(d['a'], d['k'], 2))
mut('HV1-ARRAY_RANGES-03', 'return 0 when none')(lambda d: max(ic.array_ranges(d, 2), 0))
mut('HV1-ARRAY_RANGES-04', 'fewer than k distinct')(lambda d: ic.array_ranges({**d, 'k': d['k'] - 1}, 3) if d['k'] > 1 else ic.array_ranges(d, 3))
def kadane(d):
    if not d['a']: return None
    best = cur = d['a'][0]
    for x in d['a'][1:]: cur = max(x, cur + x); best = max(best, cur)
    return best
mut('HV1-ARRAY_RANGES-05', 'Kadane ignoring length limit')(kadane)
def exact_len(d):
    a, k = d['a'], d['k']
    if not a: return None
    L = min(k, len(a))
    return max(sum(a[i:i + L]) for i in range(len(a) - L + 1))
mut('HV1-ARRAY_RANGES-05', 'length exactly min(k,n)')(exact_len)
mut('HV1-ARRAY_RANGES-05', 'empty array -> 0')(lambda d: 0 if not d['a'] else ic.array_ranges(d, 4))
mut('HV1-ARRAY_RANGES-05', 'allow empty subarray (floor 0)')(lambda d: None if not d['a'] else max(0, ic.array_ranges(d, 4)))

# ------------------------------------------------ dag_paths
def dijkstra(d, maximize=False):
    n = d['n']; dist = [None] * n; dist[0] = 0; done = set()
    while True:
        ready = [u for u in range(n) if u not in done and dist[u] is not None]
        if not ready: return None
        u = (max if maximize else min)(ready, key=lambda x: dist[x])
        if u == n - 1: return dist[u]
        done.add(u)
        for a, b, w in d['edges']:
            if a == u and b not in done and (dist[b] is None or ((dist[u] + w > dist[b]) if maximize else (dist[u] + w < dist[b]))): dist[b] = dist[u] + w
mut('HV1-DAG_PATHS-01', 'Dijkstra early finalisation')(dijkstra)
mut('HV1-DAG_PATHS-01', 'unreachable -> 0')(lambda d: ic.dag_paths(d, 0) if ic.dag_paths(d, 0) is not None else 0)
mut('HV1-DAG_PATHS-02', 'n=1 -> 0 paths')(lambda d: 0 if d['n'] == 1 else ic.dag_paths(d, 1))
mut('HV1-DAG_PATHS-03', 'count fixed at 1 when reachable')(lambda d: (lambda r: {'cost': r['cost'], 'count': min(r['count'], 1)})(ic.dag_paths(d, 2)))
mut('HV1-DAG_PATHS-04', 'greedy max (Dijkstra-style)')(lambda d: dijkstra(d, True))
mut('HV1-DAG_PATHS-04', 'n=1 -> null')(lambda d: None if d['n'] == 1 else ic.dag_paths(d, 3))
def smallest_pred(d):
    n = d['n']; best = [None] * n; best[0] = 0; par = [None] * n
    for v in range(n):
        for u, vv, w in sorted(d['edges']):
            if vv == v and best[u] is not None:
                c = best[u] + w
                if best[v] is None or c < best[v] or (c == best[v] and u < par[v]): best[v] = c; par[v] = u
    if best[n - 1] is None: return []
    p = [n - 1]
    while p[-1] != 0: p.append(par[p[-1]])
    return p[::-1]
mut('HV1-DAG_PATHS-05', 'tie-break by smallest predecessor')(smallest_pred)

# ------------------------------------------------ string_dp
mut('HV1-STRING_DP-01', 'length gap + Hamming')(lambda d: abs(len(d['a']) - len(d['b'])) + sum(x != y for x, y in zip(d['a'], d['b'])))
mut('HV1-STRING_DP-01', 'indel distance (no substitution)')(lambda d: ic.string_dp(d, 1))
mut('HV1-STRING_DP-02', 'Levenshtein (substitution allowed)')(lambda d: ic.string_dp(d, 0))
def star_one(d):
    return bool(re.fullmatch(''.join('.' if c in '?*' else re.escape(c) for c in d['b']), d['a']))
mut('HV1-STRING_DP-03', "'*' matches exactly one char")(star_one)
mut('HV1-STRING_DP-03', 'prefix match only')(lambda d: any(ic.string_dp({'a': d['a'][:i], 'b': d['b']}, 2) for i in range(len(d['a']) + 1)))
def lcsubstr(d):
    a, b = d['a'], d['b']; best = 0
    for i in range(len(a)):
        for j in range(len(b)):
            L = 0
            while i + L < len(a) and j + L < len(b) and a[i + L] == b[j + L]: L += 1
            best = max(best, L)
    return best
mut('HV1-STRING_DP-04', 'longest common substring')(lcsubstr)
mut('HV1-STRING_DP-05', 'collapse embeddings (0/1)')(lambda d: int(ic._is_subseq(d['b'], d['a'])))
mut('HV1-STRING_DP-05', 'empty b -> 0')(lambda d: 0 if d['b'] == '' else ic.string_dp(d, 4))

# ------------------------------------------------ interval_sweep
mut('HV1-INTERVAL_SWEEP-01', 'sum of lengths')(lambda d: sum(r - l for l, r in d['intervals']))
mut('HV1-INTERVAL_SWEEP-02', 'more than k (strict)')(lambda d: ic.interval_sweep({**d, 'k': d['k'] + 1}, 1))
mut('HV1-INTERVAL_SWEEP-02', 'deduplicate copies')(lambda d: ic.interval_sweep({**d, 'intervals': [list(x) for x in set(map(tuple, d['intervals']))]}, 1))
mut('HV1-INTERVAL_SWEEP-03', 'at least k instead of exactly k')(lambda d: ic.interval_sweep(d, 1))
def closed_peak(d):
    best = 0
    for x2 in range(-200, 201):
        x = x2 / 2
        best = max(best, sum(1 for l, r in d['intervals'] if l <= x <= r))
    return best
mut('HV1-INTERVAL_SWEEP-04', 'closed intervals (touching overlaps, zero-length counted)')(closed_peak)
def no_touch_merge(d):
    out = []
    for l, r in sorted(x for x in d['intervals'] if x[0] < x[1]):
        if out and l < out[-1][1]: out[-1][1] = max(out[-1][1], r)
        else: out.append([l, r])
    return out
mut('HV1-INTERVAL_SWEEP-05', 'do not merge touching intervals')(no_touch_merge)
mut('HV1-INTERVAL_SWEEP-05', 'keep zero-length intervals as pieces')(lambda d: sorted(ic.interval_sweep(d, 4) + [[l, r] for l, r in d['intervals'] if l == r and not any(a <= l < b for a, b in ic.interval_sweep(d, 4))]))

# ------------------------------------------------ dependency_dag
mut('HV1-DEPENDENCY_DAG-01', 'list(range(n))')(lambda d: list(range(d['n'])))
def kahn_fifo(d):
    n = d['n']; ind = [0] * n; succ = [[] for _ in range(n)]
    for u, v in d['edges']: succ[u].append(v); ind[v] += 1
    q = deque(i for i in range(n) if ind[i] == 0); out = []
    while q:
        u = q.popleft(); out.append(u)
        for v in succ[u]:
            ind[v] -= 1
            if ind[v] == 0: q.append(v)
    return out if len(out) == n else []
mut('HV1-DEPENDENCY_DAG-01', 'Kahn FIFO queue (not min-heap)')(kahn_fifo)
mut('HV1-DEPENDENCY_DAG-02', 'unique iff exactly one source')(lambda d: (ic.dependency_dag(d, 0) != [] or d['n'] == 0) and sum(1 for v in range(d['n']) if all(e[1] != v for e in d['edges'])) <= 1)
mut('HV1-DEPENDENCY_DAG-02', 'cycle -> true')(lambda d: True if (ic.dependency_dag(d, 0) == [] and d['n'] > 0) else ic.dependency_dag(d, 1))
mut('HV1-DEPENDENCY_DAG-03', 'sequential sum of durations')(lambda d: None if ic.dependency_dag(d, 2) is None else sum(d['duration']))
def longest_edges_only(d):
    r = ic.dependency_dag(d, 2)
    if r is None: return None
    # forget the duration of the first job on the chain
    n = d['n']; pred = [[] for _ in range(n)]
    for u, v in d['edges']: pred[v].append(u)
    import functools
    @functools.lru_cache(None)
    def f(v): return max([f(u) + d['duration'][v] for u in pred[v]] + [0])
    return max([f(v) for v in range(n)] + [0])
mut('HV1-DEPENDENCY_DAG-03', 'omit duration of chain head')(longest_edges_only)
mut('HV1-DEPENDENCY_DAG-04', 'count paths instead of distinct ancestors')(lambda d: [] if ic.dependency_dag(d, 4) is None else
    (lambda n, E: [sum(1 for s in range(n) for _ in [0] if s != v and False) for v in range(n)])(d['n'], d['edges']) and
    [c - 1 for c in _paths_ending(d)])
def _paths_ending(d):
    n = d['n']; order = ic.dependency_dag(d, 0); cnt = [1] * n
    for u in order:
        for a, b in d['edges']:
            if a == u: cnt[b] += cnt[u]
    return cnt
M['HV1-DEPENDENCY_DAG-04'] = [('count paths instead of distinct ancestors', lambda d: [] if ic.dependency_dag(d, 4) is None else [c - 1 for c in _paths_ending(d)]),
                              ('direct predecessors only (in-degree)', lambda d: [] if ic.dependency_dag(d, 4) is None else [sum(1 for a, b in d['edges'] if b == v) for v in range(d['n'])])]
mut('HV1-DEPENDENCY_DAG-05', 'exclude zero-edge paths')(lambda d: None if ic.dependency_dag(d, 4) is None else ic.dependency_dag(d, 4) - d['n'])
mut('HV1-DEPENDENCY_DAG-05', 'cycle -> 0')(lambda d: 0 if ic.dependency_dag(d, 4) is None else ic.dependency_dag(d, 4))

# ------------------------------------------------ subset_dp
def dedupe_vals(d): return ic.subset_dp({**d, 'a': sorted(set(d['a']))}, 0)
mut('HV1-SUBSET_DP-01', 'merge duplicate values')(dedupe_vals)
mut('HV1-SUBSET_DP-01', 'exclude empty subset')(lambda d: ic.subset_dp(d, 0) - (1 if d['target'] == 0 else 0))
mut('HV1-SUBSET_DP-02', 'exclude empty subset')(lambda d: (ic.subset_dp(d, 0) - (1 if d['target'] == 0 else 0)) > 0)
def lex_first(d):
    a = d['a']; n = len(a); best = None
    for m in range(1 << n):
        idx = [i for i in range(n) if m >> i & 1]
        if sum(a[i] for i in idx) == d['target'] and (best is None or idx < best): best = idx
    return best
mut('HV1-SUBSET_DP-03', 'lexicographic before cardinality')(lex_first)
mut('HV1-SUBSET_DP-03', 'none -> []')(lambda d: ic.subset_dp(d, 2) if ic.subset_dp(d, 2) is not None else [])
def greedy_part(d):
    s1 = s2 = 0
    for x in sorted(d['a'], reverse=True):
        if s1 <= s2: s1 += x
        else: s2 += x
    return abs(s1 - s2)
mut('HV1-SUBSET_DP-04', 'greedy largest-first partition')(greedy_part)
mut('HV1-SUBSET_DP-05', 'ignore k')(lambda d: ic.subset_dp(d, 0))
mut('HV1-SUBSET_DP-05', 'merge duplicate values')(lambda d: ic.subset_dp({**d, 'a': sorted(set(d['a']))}, 4) if d['k'] <= len(set(d['a'])) else 0)

# ------------------------------------------------ substring_search
def adv_len(d):
    s, p = d['text'], d['pattern']; out = []; i = 0
    while i <= len(s) - len(p):
        if s[i:i + len(p)] == p: out.append(i); i += max(1, len(p))
        else: i += 1
    return out
mut('HV1-SUBSTRING_SEARCH-01', 'advance by len(pattern) after a match')(adv_len)
mut('HV1-SUBSTRING_SEARCH-01', 'empty pattern omits end boundary')(lambda d: list(range(len(d['text']))) if d['pattern'] == '' else ic.substring_search(d, 0))
mut('HV1-SUBSTRING_SEARCH-02', 'str.count (non-overlapping)')(lambda d: d['text'].count(d['pattern']))
def strict_sel(d):
    occ = ic.substring_search(d, 0); out = []; end = -1
    for i in occ:
        if i > end: out.append(i); end = i + max(1, len(d['pattern']))
    return out
mut('HV1-SUBSTRING_SEARCH-03', 'select when start > end (strict, end=-1)')(strict_sel)
mut('HV1-SUBSTRING_SEARCH-03', 'all occurrences (no selection)')(lambda d: ic.substring_search(d, 0))
mut('HV1-SUBSTRING_SEARCH-04', 'empty pattern covers everything')(lambda d: [] if d['pattern'] == '' else ic.substring_search(d, 3))
mut('HV1-SUBSTRING_SEARCH-04', 'non-overlapping occurrences only')(lambda d: [i for i in range(len(d['text'])) if not any(j <= i < j + len(d['pattern']) for j in adv_len(d))])
mut('HV1-SUBSTRING_SEARCH-05', 'zero-based k')(lambda d: (lambda o: o[d['k']] if len(o) > d['k'] else -1)(ic.substring_search(d, 0)))
mut('HV1-SUBSTRING_SEARCH-05', 'non-overlapping occurrences')(lambda d: (lambda o: o[d['k'] - 1] if len(o) >= d['k'] else -1)(adv_len(d)))

# ------------------------------------------------ tree_dp
mut('HV1-TREE_DP-01', 'distance sum from vertex 0 repeated')(lambda d: [ic.tree_dp(d, 0)[0]] * d['n'])
mut('HV1-TREE_DP-02', 'exclude the vertex itself')(lambda d: [x - 1 for x in ic.tree_dp(d, 1)])
def ecc_one_endpoint(d):
    n = d['n']; adj = [[] for _ in range(n)]
    for u, v in d['edges']: adj[u].append(v); adj[v].append(u)
    def bfs(s):
        dist = [-1] * n; dist[s] = 0; q = deque([s])
        while q:
            x = q.popleft()
            for y in adj[x]:
                if dist[y] < 0: dist[y] = dist[x] + 1; q.append(y)
        return dist
    a = bfs(0); u = max(range(n), key=lambda i: a[i]); return bfs(u)
mut('HV1-TREE_DP-03', 'distance to one diameter endpoint only')(ecc_one_endpoint)
mut('HV1-TREE_DP-04', 'height from vertex 0')(lambda d: ic.tree_dp(d, 2)[0])
mut('HV1-TREE_DP-04', 'twice height from vertex 0 (assumes centre at 0)')(lambda d: min(2 * ic.tree_dp(d, 2)[0], 10**9))
mut('HV1-TREE_DP-05', 'ordered pairs')(lambda d: 2 * ic.tree_dp(d, 4))
mut('HV1-TREE_DP-05', 'k=0 -> n')(lambda d: d['n'] if d['k'] == 0 else ic.tree_dp(d, 4))

# ------------------------------------------------ functional_jumps
mut('HV1-FUNCTIONAL_JUMPS-01', 'one step only')(lambda d: [d['next'][u] for u, k in d['queries']])
mut('HV1-FUNCTIONAL_JUMPS-01', 'k-1 steps')(lambda d: ic.functional_jumps({**d, 'queries': [[u, max(0, k - 1)] for u, k in d['queries']]}, 0))
def sum_incl0(d):
    out = []
    for u, k in d['queries']:
        s = 0; x = u
        for _ in range(k): s += x; x = d['next'][x]
        out.append(s)
    return out
mut('HV1-FUNCTIONAL_JUMPS-02', 'times 0..k-1 (counts start label)')(sum_incl0)
mut('HV1-FUNCTIONAL_JUMPS-03', 'mu+lambda (distinct vertices visited)')(lambda d: [a + b for a, b in zip(ic.functional_jumps(d, 2), ic.functional_jumps(d, 3))])
mut('HV1-FUNCTIONAL_JUMPS-04', 'assume zero tail')(lambda d: [0] * len(d['next']))
mut('HV1-FUNCTIONAL_JUMPS-04', 'mu+1 (first repeat time)')(lambda d: [x + 1 for x in ic.functional_jumps(d, 3)])
def min_reachable(d):
    out = []
    for u in range(len(d['next'])):
        seen = []; x = u
        while x not in seen: seen.append(x); x = d['next'][x]
        out.append(min(seen))
    return out
mut('HV1-FUNCTIONAL_JUMPS-05', 'min over all reachable vertices (tail included)')(min_reachable)

# ------------------------------------------------ grid_dp
from math import comb
mut('HV1-GRID_DP-01', 'ignore blocked cells')(lambda d: comb(d['h'] + d['w'] - 2, d['h'] - 1))
mut('HV1-GRID_DP-01', 'blocked endpoints still allowed')(lambda d: ic.grid_dp({**d, 'blocked': [b for b in d['blocked'] if tuple(b) not in ((0, 0), (d['h'] - 1, d['w'] - 1))]}, 0))
def no_start_weight(d, mode):
    W = [row[:] for row in d['weights']]; W[0][0] = 0
    return ic.grid_dp({**d, 'weights': W}, mode)
mut('HV1-GRID_DP-02', 'omit start weight')(lambda d: no_start_weight(d, 1))
mut('HV1-GRID_DP-02', 'no path -> 0')(lambda d: ic.grid_dp(d, 1) if ic.grid_dp(d, 1) is not None else 0)
mut('HV1-GRID_DP-03', 'count all paths, not minimum ones')(lambda d: (lambda r: {'cost': r['cost'], 'count': ic.grid_dp(d, 0)})(ic.grid_dp(d, 2)))
def no_end_weight(d, mode):
    W = [row[:] for row in d['weights']]; W[-1][-1] = 0
    return ic.grid_dp({**d, 'weights': W}, mode)
mut('HV1-GRID_DP-04', 'omit destination weight')(lambda d: no_end_weight(d, 3))
def fwd_reach(d):
    h, w = d['h'], d['w']; B = {tuple(x) for x in d['blocked']}
    R = set()
    for r in range(h):
        for c in range(w):
            if (r, c) in B: continue
            if (r, c) == (0, 0) or (r - 1, c) in R or (r, c - 1) in R: R.add((r, c))
    return [list(x) for x in sorted(R)]
mut('HV1-GRID_DP-05', 'forward-reachable cells only')(fwd_reach)

# ------------------------------------------------ calibration: ignore the disclosed transform
for tid, fam in [('CAL-ARRAY_RANGES-06', 'array_ranges'), ('CAL-STRING_DP-06', 'string_dp'), ('CAL-DEPENDENCY_DAG-06', 'dependency_dag'),
                 ('CAL-SUBSTRING_SEARCH-06', 'substring_search'), ('CAL-FUNCTIONAL_JUMPS-06', 'functional_jumps')]:
    M.setdefault(tid, []).append(('ignore the disclosed transform', (lambda fam: lambda d: getattr(ic, fam)(d, 0))(fam)))
def cal_sub_mapback(d):
    t = ic.transform('substring_search', d); occ = ic.substring_search(t, 0); L = len(d['text']); p = len(d['pattern'])
    return sorted(L - p - i for i in occ)
M['CAL-SUBSTRING_SEARCH-06'].append(('map positions back to original text', cal_sub_mapback))

def main(root):
    cases = json.load(open(root + '/private/coding_cases.json'))
    rows = []
    for tid in sorted(M):
        for name, fn in M[tid]:
            killed_by = None; how = None; nkill = 0; exc = 0
            for c in cases[tid]:
                try:
                    out = json.loads(json.dumps(fn(c['input'])))
                except Exception as e:
                    out = ('EXC', type(e).__name__ + ':' + str(e)[:60]); exc += 1
                if json.dumps(out) != json.dumps(c['expected']):
                    nkill += 1
                    if killed_by is None: killed_by = c['case_id']; how = 'exception ' + out[1] if isinstance(out, tuple) else 'wrong output'
            rows.append({'id': tid, 'mutant': name, 'killed_by': killed_by, 'how': how, 'cases_failed': nkill, 'cases_total': len(cases[tid]), 'exceptions': exc})
    surv = [r for r in rows if r['killed_by'] is None]
    print('mutants:', len(rows), '| killed:', len(rows) - len(surv), '| SURVIVED:', len(surv))
    for r in surv: print('  SURVIVES', r['id'], '|', r['mutant'])
    for r in rows:
        if r['exceptions']: print('  MUTANT RAISED', r['id'], r['mutant'], r['how'])
    weak = [r for r in rows if r['cases_failed'] and r['cases_failed'] <= 2]
    print('mutants killed by only 1-2 cases:', len(weak))
    for r in weak: print('   weakly killed', r['id'], '|', r['mutant'], '|', r['cases_failed'], 'of', r['cases_total'])
    json.dump(rows, open('mutant_results.json', 'w'), indent=1)

if __name__ == '__main__':
    main(sys.argv[1])
