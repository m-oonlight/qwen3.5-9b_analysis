"""Probe the proposed adapter (score_response.py) and the pinned scorer (study_score_v2.py) with crafted
responses. Only crafted strings are scored; no model output and no code execution."""
import json, sys, importlib.util
root = sys.argv[1]
def load(name, path):
    s = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
new = load('score_response', root + '/score_response.py')
import os
pin = load('study_score_v2', os.environ['PINNED_SCORER'])  # pinned study_score_v2.py or the byte-identical package copy
tasks = {t['id']: t for t in json.load(open(root + '/public/tasks.json'))}
keys = {k['id']: k for k in json.load(open(root + '/private/answer_keys.json'))}
T = 'HV1-VERTEX_COVER-01'; t, k = tasks[T], keys[T]
good = json.dumps(k['expected'])
reordered = json.dumps({'answer': {'vertices': k['expected']['answer']['vertices'], 'cost': k['expected']['answer']['cost']}})
probes = {
  'canonical': 'Working...\nFINAL_JSON: ' + good,
  'canonical + trailing newline': 'FINAL_JSON: ' + good + '\n',
  'pretty-printed multi-line JSON': 'FINAL_JSON:\n' + json.dumps(k['expected'], indent=2),
  'object keys in different order': 'FINAL_JSON: ' + reordered,
  'json code fence': 'FINAL_JSON:\n```json\n' + good + '\n```',
  'trailing period': 'FINAL_JSON: ' + good + '.',
  'marker also used earlier in working': 'I will end with FINAL_JSON: and the object.\nFINAL_JSON: ' + good,
  'cost as float 18.0': 'FINAL_JSON: ' + good.replace('"cost": 18', '"cost": 18.0'),
  'cost as string "18"': 'FINAL_JSON: ' + good.replace('"cost": 18', '"cost": "18"'),
}
print('== finite responses: new adapter vs pinned scorer (task %s) ==' % T)
for name, resp in probes.items():
    a = new.score_math(resp, t, k)['correct']
    b = pin.score_final(resp, k, t['category'], 'stop')['correct']
    print('%-40s new=%-5s pinned=%s' % (name, a, b))
# coding extraction
code = 'def solve(data):\n    return 1'
cp = {
  'canonical ```python': 'FINAL_CODE:\n```python\n' + code + '\n```',
  'fence tag ```py': 'FINAL_CODE:\n```py\n' + code + '\n```',
  'fence tag ```Python': 'FINAL_CODE:\n```Python\n' + code + '\n```',
  'untagged ``` fence': 'FINAL_CODE:\n```\n' + code + '\n```',
  'CRLF line endings': ('FINAL_CODE:\n```python\n' + code + '\n```').replace('\n', '\r\n'),
  'draft FINAL_CODE block earlier in content': 'Draft:\nFINAL_CODE:\n```python\ndef solve(data):\n    return 0\n```\nFixed version:\nFINAL_CODE:\n```python\n' + code + '\n```',
  'docstring with ``` inside code': 'FINAL_CODE:\n```python\ndef solve(data):\n    """e.g. ```x```"""\n    return 1\n```',
}
print('\n== coding extraction: new extract_code vs pinned score_final(category="coding") ==')
for name, resp in cp.items():
    a = new.extract_code(resp)['status']
    b = pin.score_final(resp, {}, 'coding', 'stop')['status']
    print('%-44s new=%-26s pinned=%s' % (name, a, b))
# pinned scorer fed a NEW coding task as-is
ct = tasks['HV1-ARRAY_RANGES-01']; ck = keys['HV1-ARRAY_RANGES-01']
r = pin.score_final(cp['canonical ```python'], ck, ct['category'], 'stop')
print('\npinned score_final on a new coding task with its own category %r -> status %r' % (ct['category'], r['status']))
print('new coding key expected.cases field is a', type(ck['expected']['cases']).__name__, '->', ck['expected']['cases'])
