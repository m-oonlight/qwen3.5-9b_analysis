import os, sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
"""Run every package reference and slow-correct solution through the emulated pinned harness."""
import json, sys
from emu_suite import run_suite, policy
root = sys.argv[1]
cases = json.load(open(root + '/private/coding_cases.json'))
keys = {k['id']: k for k in json.load(open(root + '/private/answer_keys.json')) + json.load(open(root + '/private/calibration_keys.json'))}
rows = []
for tid in sorted(cases):
    k = keys[tid]
    for kind, path in (('reference', k['solver']), ('slow_correct', k['checker'])):
        code = open(root + '/' + path).read()
        res = run_suite(code, tid, [{'input': c['input'], 'expected': c['expected']} for c in cases[tid]])
        rows.append({'id': tid, 'kind': kind, 'status': res.get('status'), 'passed': res.get('passed'), 'total': res.get('total'),
                     'cpu_s': res.get('cpu_s'), 'wall_s': res.get('wall_s'), 'maxrss_mb': res.get('maxrss_mb'),
                     'failures': res.get('failures', [])[:3], 'extra': res.get('stderr', res.get('detail'))})
        print(tid, kind, rows[-1]['status'], rows[-1]['passed'], '/', rows[-1]['total'], 'cpu', rows[-1]['cpu_s'], 'rss', rows[-1]['maxrss_mb'], flush=True)
json.dump(rows, open('ref_slow_runs.json', 'w'), indent=1)
