import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import json, sys
from emu_suite import run_suite, policy
root = sys.argv[1]
cases = json.load(open(root + '/private/coding_cases.json'))
wrong = json.load(open(root + '/private/known_wrong_programs.json'))
out = []
for w in wrong:
    cs = cases[w['task_id']]
    res = run_suite(w['code'], w['task_id'], [{'input': c['input'], 'expected': c['expected']} for c in cs])
    fails = [f['case'] for f in res.get('failures', [])]
    witness_idx = next(i for i, c in enumerate(cs) if c['case_id'] == w['witness_case'])
    row = dict(family=w['family'], task=w['task_id'], policy=policy(w['code'])[0], status=res['status'], passed=res.get('passed'), total=res.get('total'),
               failing_cases=len(fails), declared_witness=w['witness_case'], witness_actually_fails=witness_idx in fails,
               failure_kinds=sorted({f['status'] for f in res.get('failures', [])}))
    out.append(row); print(row)
json.dump(out, open('wrong_runs.json', 'w'), indent=1)
