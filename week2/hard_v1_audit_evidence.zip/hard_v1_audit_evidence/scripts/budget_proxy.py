"""Measured proxies (not difficulty measurements): size of the literal search space a direct method must
cover, and answer length. Used only to flag tasks for the calibration pilot."""
import json, sys, math, itertools
from collections import defaultdict
root = sys.argv[1]
T = json.load(open(root + '/public/tasks.json')) + json.load(open(root + '/public/calibration.json'))
K = {k['id']: k for k in json.load(open(root + '/private/answer_keys.json')) + json.load(open(root + '/private/calibration_keys.json'))}
def D(t): return json.loads(t['prompt'].split('\nData (exact JSON): ', 1)[1].split('\n', 1)[0])
def space(f, d):
    if f == 'modular_roots': return d['m']
    if f == 'divisor_filter': return sum(1 for x in range(1, d['n'] + 1) if d['n'] % x == 0)
    if f == 'digit_automaton': return d['base'] ** d['length']
    if f == 'crt_window': return d['hi'] - d['lo'] + 1
    if f == 'factorial_valuation': return len(d['primes'])
    if f == 'integer_system': return (2 * d['bound'] + 1) ** 2
    if f == 'rational_roots': return 2 * d['bound'] + 1
    if f == 'finite_linear': return d['p'] ** len(d['a'][0])
    if f == 'interpolation': return len(d['points'])
    if f == 'floor_equation': return d['hi'] - d['lo'] + 1
    if f == 'multiset_words': return math.factorial(sum(d['counts'])) // math.prod(math.factorial(c) for c in d['counts'])
    if f == 'independent_subset': return math.comb(len(d['weights']), d['k'])
    if f == 'bounded_composition': return math.prod(c + 1 for c in d['caps'])
    if f == 'restricted_permutation': return math.factorial(d['n'])
    if f == 'grid_paths': return math.comb(d['w'] + d['h'], d['h'])
    if f == 'urn_conditional': return math.comb(sum(d['counts']), d['draw'])
    if f == 'walk_probability': return len(d['steps']) ** d['n']
    if f == 'permutation_probability': return math.factorial(d['n'])
    if f == 'subset_probability': return math.comb(d['n'], d['k']) ** 2
    if f == 'network_reliability': return 2 ** len(d['edges'])
    if f == 'vertex_cover': return 2 ** d['n']
    if f == 'spanning_tree': return math.comb(len(d['edges']), d['n'] - 1)
    if f == 'resource_path': return len(d['edges'])
    if f == 'assignment': return math.factorial(len(d['cost']))
    if f == 'interval_schedule': return 2 ** len(d['jobs'])
    if f == 'coupled_recurrence': return d['n']
    if f == 'substitution':
        s = d['start']
        for _ in range(d['n']): s = ''.join(d['rules'][int(c)] for c in s)
        return len(s)
    if f == 'functional_graph': return K_ans['preperiod'] + K_ans['period']
    if f == 'subtraction_game': return d['n']
    if f == 'periodic_matrix': return d['n']
    if f == 'boolean_models': return math.comb(d['n'], d['weight'])
    if f == 'precedence_orders': return math.factorial(d['n'])
    if f == 'relational_query': return len(d['a']) * len(d['b'])
    if f == 'truth_cycle': return 2 ** d['n']
    if f == 'transaction_log': return len(d['ops'])
    if f == 'matching_clues': return math.factorial(d['n'])
    if f == 'set_membership': return (d['cap'] + 1) ** 7
    if f == 'cellular_ring': return d['n'] * len(d['initial'])
    if f == 'dfa_language': return math.comb(d['length'] - d['ones'] + 1, d['ones'])
    if f == 'poset_ideals': return math.comb(d['n'], d['k'])
UNIT = {'coupled_recurrence': 'iterations', 'periodic_matrix': 'mat-vec steps', 'cellular_ring': 'cell updates', 'substitution': 'final string length',
        'functional_graph': 'orbit length (mu+lambda)', 'subtraction_game': 'Grundy values', 'transaction_log': 'operations', 'resource_path': 'edges',
        'interpolation': 'points', 'factorial_valuation': 'primes', 'dfa_language': 'no-11 candidates', 'boolean_models': 'weight-w vectors'}
rows = defaultdict(list)
for t in T:
    if t['category'] == 'algorithmic_python': continue
    f = t['family']; d = D(t); K_ans = K[t['id']]['expected']['answer']
    rows[(t['category'], f)].append((space(f, d), len(json.dumps(K_ans, separators=(',', ':')))))
out = []
for (cat, f), v in sorted(rows.items()):
    sp = [x for x, _ in v]; al = [y for _, y in v]
    out.append(dict(category=cat, family=f, unit=UNIT.get(f, 'candidates'), space_min=min(sp), space_max=max(sp), answer_chars_max=max(al)))
    print('%-30s %-24s %-24s %9d..%-9d ans<=%d' % (cat, f, UNIT.get(f, 'candidates'), min(sp), max(sp), max(al)))
json.dump(out, open('budget_proxy.json', 'w'), indent=1)
