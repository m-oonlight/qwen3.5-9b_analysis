"""Auditor's independent oracles for the 55 hard_v1 coding tasks, written from the PUBLIC PROMPT TEXT.
Methods deliberately differ from the package's reference (Fenwick/deque/KMP/rerooting/binary lifting)
and from its 'slow' oracles (slice enumeration, Floyd-Warshall, permutation enumeration):
  array_ranges     running-sum O(n^2) scan
  dag_paths        exact cost-distribution DP (cost -> #paths) + greedy lexicographic reconstruction
  string_dp        BFS over edit operations (short strings) / LCS identity / fnmatch / combinations
  interval_sweep   unit-cell discretisation of the integer line
  dependency_dag   DFS colouring, Hamiltonian-path uniqueness test, memoised longest path, BFS ancestors
  subset_dp        incremental bitmask sums over all 2^n subsets
  substring_search regex look-ahead (re module)
  tree_dp          BFS from every vertex; subtree sizes by ancestor walking
  functional_jumps tail/cycle arithmetic (no lifting, no step-by-step walk for long k)
  grid_dp          full enumeration of all monotone paths (feasible: <= C(16,8)=12870)
Run: python3 -I indep_coding.py <hard_v1 dir>
"""
import json, sys, itertools, re, fnmatch
from collections import deque, Counter

# ---------------------------------------------------------------- array_ranges
def array_ranges(d, mode):
    a, k = d['a'], d['k']; n = len(a)
    best = None; cnt = 0
    for i in range(n):
        s = 0; seen = Counter()
        for j in range(i, n):
            s += a[j]; seen[a[j]] += 1; L = j - i + 1
            if mode == 0 and s <= k: best = L if best is None else max(best, L)
            if mode == 1 and s == k: cnt += 1
            if mode == 2 and s >= k: best = L if best is None else min(best, L)
            if mode == 3 and len(seen) <= k: best = L if best is None else max(best, L)
            if mode == 4 and L <= k: best = s if best is None else max(best, s)
    if mode == 0: return best or 0
    if mode == 1: return cnt
    if mode == 2: return -1 if best is None else best
    if mode == 3: return best or 0
    return best  # None for empty a

# ---------------------------------------------------------------- dag_paths
def dag_paths(d, mode):
    n = d['n']; E = d['edges']
    # dist[v] = Counter(cost -> number of paths 0->v)
    dist = [Counter() for _ in range(n)]; dist[0][0] = 1
    for v in range(n):  # labels are a topological order
        for u, vv, w in E:
            if vv == v:
                for c, m in dist[u].items():
                    dist[v][c + w] += m
    D = dist[n - 1]
    if mode == 1: return sum(D.values())
    if not D:
        return {0: None, 2: {'cost': None, 'count': 0}, 3: None, 4: []}[mode]
    if mode == 0: return min(D)
    if mode == 3: return max(D)
    if mode == 2: c = min(D); return {'cost': c, 'count': D[c]}
    # mode 4: greedy lexicographic reconstruction using exact min-cost-to-target
    INF = float('inf')
    to_t = [INF] * n; to_t[n - 1] = 0
    for u in range(n - 1, -1, -1):
        for uu, v, w in E:
            if uu == u and to_t[v] < INF: to_t[u] = min(to_t[u], w + to_t[v])
    best = min(D); path = [0]; u = 0; acc = 0
    while u != n - 1:
        cands = sorted(v for uu, v, w in E if uu == u and acc + w + to_t[v] == best)
        v = cands[0]; acc += next(w for uu, vv, w in E if uu == u and vv == v); path.append(v); u = v
    return path

# ---------------------------------------------------------------- string_dp
def _bfs_edit(a, b, allow_sub):
    if len(a) + len(b) > 9: return None
    seen = {a: 0}; q = deque([a]); alph = 'ab'
    while q:
        s = q.popleft()
        if s == b: return seen[s]
        nxt = set()
        for i in range(len(s)):
            nxt.add(s[:i] + s[i + 1:])
            if allow_sub:
                for c in alph: nxt.add(s[:i] + c + s[i + 1:])
        for i in range(len(s) + 1):
            for c in alph: nxt.add(s[:i] + c + s[i:])
        for t in nxt:
            if t not in seen and len(t) <= len(a) + len(b):
                seen[t] = seen[s] + 1; q.append(t)

def _lcs(a, b):
    # Hunt-Szymanski-like: dictionary DP over b positions (different code path from row DP)
    prev = {}
    L = [[0] * (len(b) + 1) for _ in range(len(a) + 1)]
    for i in range(len(a) - 1, -1, -1):
        for j in range(len(b) - 1, -1, -1):
            L[i][j] = L[i + 1][j + 1] + 1 if a[i] == b[j] else max(L[i + 1][j], L[i][j + 1])
    return L[0][0]

def _lev(a, b):
    # memoised suffix recursion (different orientation from the package's prefix row DP)
    import functools
    @functools.lru_cache(maxsize=None)
    def f(i, j):
        if i == len(a): return len(b) - j
        if j == len(b): return len(a) - i
        return min(f(i + 1, j) + 1, f(i, j + 1) + 1, f(i + 1, j + 1) + (a[i] != b[j]))
    sys.setrecursionlimit(10000)
    return f(0, 0)

def string_dp(d, mode):
    a, b = d['a'], d['b']
    if mode == 0:
        r = _bfs_edit(a, b, True); v = _lev(a, b)
        assert r is None or r == v, ('bfs/lev disagree', a, b, r, v)
        return v
    if mode == 1:
        r = _bfs_edit(a, b, False); v = len(a) + len(b) - 2 * _lcs(a, b)
        assert r is None or r == v
        return v
    if mode == 2:
        return fnmatch.fnmatchcase(a, b)
    if mode == 3:
        v = _lcs(a, b)
        if len(a) <= 10:
            brute = max([L for L in range(len(a) + 1) for idx in itertools.combinations(range(len(a)), L)
                         if _is_subseq(''.join(a[i] for i in idx), b)] or [0])
            assert brute == v
        return v
    # mode 4
    if len(a) <= 14:
        return sum(1 for idx in itertools.combinations(range(len(a)), len(b)) if ''.join(a[i] for i in idx) == b)
    # right-to-left DP over suffixes (different orientation)
    m = len(b); cnt = [0] * (m + 1); cnt[m] = 1
    for i in range(len(a) - 1, -1, -1):
        for j in range(m):
            if a[i] == b[j]: cnt[j] += cnt[j + 1]
    return cnt[0]

def _is_subseq(s, t):
    it = iter(t); return all(c in it for c in s)

# ---------------------------------------------------------------- interval_sweep
def interval_sweep(d, mode):
    cov = Counter()
    for l, r in d['intervals']:
        for x in range(l, r): cov[x] += 1   # unit cell [x, x+1)
    cells = range(-100, 100)
    if mode == 0: return sum(1 for x in cells if cov[x] > 0)
    if mode == 1: return sum(1 for x in cells if cov[x] >= d['k'])
    if mode == 2: return sum(1 for x in cells if cov[x] == d['k'])
    if mode == 3: return max([cov[x] for x in cells] + [0])
    out = []
    for x in cells:
        if cov[x] > 0:
            if out and out[-1][1] == x: out[-1][1] = x + 1
            else: out.append([x, x + 1])
    return out

# ---------------------------------------------------------------- dependency_dag
def dependency_dag(d, mode):
    n = d['n']; E = d['edges']
    succ = [[] for _ in range(n)]; pred = [[] for _ in range(n)]
    for u, v in E: succ[u].append(v); pred[v].append(u)
    # cycle detection by DFS colouring
    color = [0] * n; cyc = False
    sys.setrecursionlimit(10000)
    def dfs(u):
        nonlocal cyc
        color[u] = 1
        for v in succ[u]:
            if color[v] == 1: cyc = True
            elif color[v] == 0: dfs(v)
        color[u] = 2
    for u in range(n):
        if color[u] == 0: dfs(u)
    if cyc:
        return {0: [], 1: False, 2: None, 3: [], 4: None}[mode]
    # lexicographically smallest order: repeatedly pick the smallest vertex all of whose preds are placed (O(n^2) scan)
    placed = set(); order = []
    while len(order) < n:
        v = min(x for x in range(n) if x not in placed and all(p in placed for p in pred[x]))
        placed.add(v); order.append(v)
    if mode == 0: return order
    if mode == 1:
        # unique topological order <=> consecutive vertices of (any) topological order are joined by an edge
        es = set(map(tuple, E))
        return all((order[i], order[i + 1]) in es for i in range(n - 1))
    import functools
    @functools.lru_cache(maxsize=None)
    def longest_ending(v):  # max total duration of a chain ending at v
        return d['duration'][v] + max([longest_ending(u) for u in pred[v]] + [0])
    if mode == 2: return max([longest_ending(v) for v in range(n)] + [0])
    if mode == 3:
        out = []
        for v in range(n):
            seen = set(); q = deque([v])
            while q:
                x = q.popleft()
                for p in pred[x]:
                    if p not in seen: seen.add(p); q.append(p)
            out.append(len(seen - {v}))
        return out
    @functools.lru_cache(maxsize=None)
    def paths_from(v):  # number of paths starting at v (including the zero-edge one)
        return 1 + sum(paths_from(w) for w in succ[v])
    return sum(paths_from(v) for v in range(n))

# ---------------------------------------------------------------- subset_dp
def subset_dp(d, mode):
    a = d['a']; n = len(a); T = d['target']
    N = 1 << n
    sums = [0] * N; pc = [0] * N
    for mask in range(1, N):
        low = mask & -mask; i = low.bit_length() - 1
        sums[mask] = sums[mask ^ low] + a[i]; pc[mask] = pc[mask ^ low] + 1
    if mode == 0: return sum(1 for m in range(N) if sums[m] == T)
    if mode == 1: return any(sums[m] == T for m in range(N))
    if mode == 3:
        tot = sum(a); return min(abs(tot - 2 * s) for s in sums)
    if mode == 4: return sum(1 for m in range(N) if sums[m] == T and pc[m] == d['k'])
    best = None
    for m in range(N):
        if sums[m] == T:
            idx = [i for i in range(n) if m >> i & 1]
            cand = (pc[m], idx)
            if best is None or cand < best: best = cand
    return None if best is None else best[1]

# ---------------------------------------------------------------- substring_search
def substring_search(d, mode):
    s, p = d['text'], d['pattern']
    if p == '':
        occ = list(range(len(s) + 1))
    else:
        occ = [m.start() for m in re.finditer('(?=' + re.escape(p) + ')', s)]
    if mode == 0: return occ
    if mode == 1: return len(occ)
    if mode == 2:
        out = []; end = 0
        for i in occ:
            if i >= end: out.append(i); end = i + max(1, len(p))
        return out
    if mode == 3:
        covered = [False] * len(s)
        for i in occ:
            for j in range(i, i + len(p)): covered[j] = True
        return [i for i in range(len(s)) if not covered[i]]
    k = d['k']
    return occ[k - 1] if len(occ) >= k else -1

# ---------------------------------------------------------------- tree_dp
def tree_dp(d, mode):
    n = d['n']; adj = [[] for _ in range(n)]
    for u, v in d['edges']: adj[u].append(v); adj[v].append(u)
    def bfs(s):
        dist = [-1] * n; dist[s] = 0; q = deque([s])
        while q:
            x = q.popleft()
            for y in adj[x]:
                if dist[y] < 0: dist[y] = dist[x] + 1; q.append(y)
        return dist
    if mode == 1:
        d0 = bfs(0); par = [-1] * n
        for v in range(n):
            for y in adj[v]:
                if d0[y] == d0[v] - 1: par[v] = y
        size = [0] * n
        for v in range(n):          # walk each vertex up to the root, crediting every ancestor (incl. itself)
            x = v
            while x != -1: size[x] += 1; x = par[x]
        return size
    D = [bfs(s) for s in range(n)]
    if mode == 0: return [sum(r) for r in D]
    if mode == 2: return [max(r) for r in D]
    if mode == 3: return max(max(r) for r in D)
    k = d['k']
    if k == 0: return 0
    return sum(1 for i in range(n) for j in range(i + 1, n) if D[i][j] == k)

# ---------------------------------------------------------------- functional_jumps
def _tail_cycle(nxt, u):
    seq = []; pos = {}
    while u not in pos: pos[u] = len(seq); seq.append(u); u = nxt[u]
    mu = pos[u]; return seq, mu, seq[mu:]

def functional_jumps(d, mode):
    nxt = d['next']; n = len(nxt)
    if mode in (0, 1):
        out = []
        for u, k in d['queries']:
            seq, mu, cyc = _tail_cycle(nxt, u)   # seq[t] = vertex at time t for t < len(seq)
            L = len(cyc)
            def at(t): return seq[t] if t < len(seq) else cyc[(t - mu) % L]
            if mode == 0: out.append(at(k)); continue
            # sum of labels at times 1..k by arithmetic on the eventual cycle
            if k < len(seq): out.append(sum(seq[1:k + 1])); continue
            total = sum(seq[1:])                      # times 1..len(seq)-1
            rem = k - (len(seq) - 1)                  # times len(seq)..k, all on the cycle
            start = (len(seq) - mu) % L               # cycle offset of time len(seq)
            full, part = divmod(rem, L)
            total += full * sum(cyc) + sum(cyc[(start + i) % L] for i in range(part))
            out.append(total)
        return out
    out = []
    for u in range(n):
        seq, mu, cyc = _tail_cycle(nxt, u)
        out.append(len(cyc) if mode == 2 else mu if mode == 3 else min(cyc))
    return out

# ---------------------------------------------------------------- grid_dp
def grid_dp(d, mode):
    h, w = d['h'], d['w']; B = {tuple(x) for x in d['blocked']}; W = d['weights']
    paths = []
    for downs in itertools.combinations(range(h + w - 2), h - 1):
        r = c = 0; cells = [(0, 0)]; ds = set(downs)
        for i in range(h + w - 2):
            if i in ds: r += 1
            else: c += 1
            cells.append((r, c))
        if any(x in B for x in cells): continue
        paths.append((sum(W[r][c] for r, c in cells), cells))
    if mode == 0: return len(paths)
    if mode == 4: return [list(x) for x in sorted({x for _, cs in paths for x in cs})]
    if not paths: return {'cost': None, 'count': 0} if mode == 2 else None
    costs = [c for c, _ in paths]
    if mode == 1: return min(costs)
    if mode == 3: return max(costs)
    return {'cost': min(costs), 'count': costs.count(min(costs))}

# ---------------------------------------------------------------- calibration transforms (from public prompt text)
def transform(fam, d):
    d = json.loads(json.dumps(d))
    if fam == 'array_ranges': d['a'] = [-x for x in d['a']]
    elif fam == 'string_dp': d['a'] = d['a'] + 'a'
    elif fam == 'dependency_dag': d['edges'] = [[v, u] for u, v in d['edges']]
    elif fam == 'substring_search': d['text'] = d['text'][::-1]; d['pattern'] = d['pattern'][::-1]
    elif fam == 'functional_jumps': d['queries'] = [[u, max(0, k - 1)] for u, k in d['queries']]
    else: raise ValueError(fam)
    return d

# ---------------------------------------------------------------- published input-domain validation
def valid_input(fam, d):
    try:
        if fam == 'array_ranges':
            return len(d['a']) <= 120 and all(-20 <= x <= 20 for x in d['a']) and 1 <= d['k'] <= 30
        if fam == 'dag_paths':
            n = d['n']; E = d['edges']; pairs = [(u, v) for u, v, w in E]
            return 1 <= n <= 16 and len(E) <= 40 and len(set(pairs)) == len(pairs) and all(0 <= u < v < n and -9 <= w <= 9 for u, v, w in E)
        if fam == 'string_dp':
            return len(d['a']) <= 120 and len(d['b']) <= 120 and set(d['a']) <= set('ab')
        if fam == 'interval_sweep':
            return len(d['intervals']) <= 120 and 1 <= d['k'] <= 20 and all(-100 <= l <= r <= 100 for l, r in d['intervals'])
        if fam == 'dependency_dag':
            n = d['n']; E = [tuple(e) for e in d['edges']]
            return 0 <= n <= 50 and len(E) <= 150 and len(set(E)) == len(E) and all(u != v and 0 <= u < n and 0 <= v < n for u, v in E) \
                and len(d['duration']) == n and all(1 <= x <= 9 for x in d['duration'])
        if fam == 'subset_dp':
            n = len(d['a']); return n <= 20 and all(-10 <= x <= 10 for x in d['a']) and -100 <= d['target'] <= 100 and 0 <= d['k'] <= n
        if fam == 'substring_search':
            return len(d['text']) <= 240 and len(d['pattern']) <= 60 and 1 <= d['k'] <= 250 and set(d['text'] + d['pattern']) <= set('ab')
        if fam == 'tree_dp':
            n = d['n']; E = d['edges']
            if not (1 <= n <= 120 and 0 <= d['k'] <= 120 and len(E) == n - 1): return False
            par = list(range(n))
            def f(x):
                while par[x] != x: x = par[x]
                return x
            for u, v in E:
                if f(u) == f(v): return False
                par[f(u)] = f(v)
            return True
        if fam == 'functional_jumps':
            n = len(d['next']); return 1 <= n <= 120 and all(0 <= x < n for x in d['next']) and len(d['queries']) <= 80 \
                and all(0 <= u < n and 0 <= k <= 100000 for u, k in d['queries'])
        if fam == 'grid_dp':
            h, w = d['h'], d['w']; B = [tuple(x) for x in d['blocked']]
            return 1 <= h <= 9 and 1 <= w <= 9 and len(set(B)) == len(B) and all(0 <= r < h and 0 <= c < w for r, c in B) \
                and len(d['weights']) == h and all(len(row) == w and all(-5 <= x <= 9 for x in row) for row in d['weights'])
    except Exception:
        return False

def norm(x):
    return json.loads(json.dumps(x))

def main(root):
    tasks = json.load(open(root + '/public/tasks.json')) + json.load(open(root + '/public/calibration.json'))
    keys = {k['id']: k for k in json.load(open(root + '/private/answer_keys.json')) + json.load(open(root + '/private/calibration_keys.json'))}
    cases = json.load(open(root + '/private/coding_cases.json'))
    total = bad = invalid = 0; problems = []
    for t in tasks:
        if t['category'] != 'algorithmic_python': continue
        fam = t['family']; mode = keys[t['id']]['mode']; cal = t['id'].startswith('CAL')
        assert mode == (0 if cal else t['instance'] - 1), ('mode label mismatch', t['id'])
        # cross-check the mode against the public objective sentence (so the key's mode label is not trusted blindly)
        for c in cases[t['id']]:
            total += 1
            if not valid_input(fam, c['input']):
                invalid += 1; problems.append((t['id'], c['case_id'], 'INPUT_OUTSIDE_PUBLISHED_DOMAIN'))
            dd = transform(fam, c['input']) if cal else c['input']
            mine = norm(globals()[fam](dd, mode))
            if json.dumps(mine) != json.dumps(c['expected']):
                bad += 1; problems.append((t['id'], c['case_id'], 'MISMATCH', mine, c['expected']))
    print('coding cases checked:', total, '| mismatches:', bad, '| inputs outside published domain:', invalid)
    for p in problems[:50]: print(p)
    json.dump(problems, open('indep_coding_problems.json', 'w'), indent=1)

if __name__ == '__main__':
    main(sys.argv[1])
