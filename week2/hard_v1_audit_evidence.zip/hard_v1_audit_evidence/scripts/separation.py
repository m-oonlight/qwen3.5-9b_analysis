import json, sys, re, hashlib, difflib
from collections import Counter
root = sys.argv[1]; old = sys.argv[2] if len(sys.argv) > 2 else None
T = json.load(open(root + '/public/tasks.json')); C = json.load(open(root + '/public/calibration.json'))
K = json.load(open(root + '/private/answer_keys.json')); CK = json.load(open(root + '/private/calibration_keys.json'))
print('primary', len(T), 'calibration', len(C), 'keys', len(K), len(CK))
print('category counts:', dict(Counter(t['category'] for t in T)))
print('calibration categories:', dict(Counter(t['category'] for t in C)))
fam = Counter(t['family'] for t in T); print('primary families', len(fam), 'sizes', set(fam.values()))
ids = [t['id'] for t in T + C]; print('unique ids', len(set(ids)) == len(ids))
print('public fields:', sorted(set().union(*[t.keys() for t in T + C])))
# answers appearing verbatim in public prompts
km = {k['id']: k for k in K + CK}; leaks = []
for t in T + C:
    k = km[t['id']]
    if t['category'] != 'algorithmic_python':
        a = json.dumps(k['expected']['answer'], separators=(',', ':'))
        if len(a) > 3 and a in t['prompt']: leaks.append(t['id'])
print('finite answers appearing verbatim in their prompt:', leaks)
# coding hint text inside public prompts
hint = [t['id'] for t in T + C if t['category'] == 'algorithmic_python' and t['difficulty_rationale'] in t['prompt']]
print('coding prompts that contain their own solution-method sentence:', len(hint), 'of', sum(t['category'] == 'algorithmic_python' for t in T + C))
# calibration vs primary overlap
def data(t): return t['prompt'].split('\nData (exact JSON): ', 1)[1].split('\n', 1)[0] if 'Data (exact JSON)' in t['prompt'] else None
pd = {data(t) for t in T if data(t)}; cd = [data(t) for t in C if data(t)]
print('calibration prompts identical to a primary prompt:', len({t['prompt'] for t in C} & {t['prompt'] for t in T}))
print('calibration finite data identical to a primary instance:', sum(d in pd for d in cd))
print('calibration families that also occur in the primary exam:', sum(t['family'] in fam for t in C), 'of', len(C))
# legacy overlap with the pinned study_v2 public tasks (public prompts only)
if old is None:
    print('legacy check skipped (pass datasets/study_v2/public/tasks.json from the pinned archive)'); sys.exit(0)
O = json.load(open(old))
oid = {t['id'] for t in O}; print('legacy tasks', len(O), '| id overlap', len(oid & set(ids)))
norm = lambda s: re.sub(r'\s+', ' ', s).strip().lower()
on = [norm(t['prompt']) for t in O]
best = max((difflib.SequenceMatcher(None, norm(t['prompt'])[:600], o[:600]).ratio(), t['id']) for t in T + C for o in on)
print('max prefix similarity new-vs-legacy prompt (difflib, first 600 chars):', round(best[0], 3), best[1])
